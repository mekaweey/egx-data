/* Background service worker.
 * - Phase 1: ticks ingest (read-only)  → handleTicks/handleWatchlist/flush
 * - Phase 2: Semi-Auto orders         → pollOrders + dispatchOrder
 *
 * Semi-Auto rules:
 *   - Auto-Execute is OFF by default. User must enable in popup.
 *   - Max N orders per day (user-configurable, default 3).
 *   - Per-order timeout: skip only after expires_at (server-controlled).
 *   - We DO NOT click the final "مراجعة الطلب" / confirm button. We stop
 *     at the prepared form so the user reviews and submits.
 */

const FLUSH_MS = 2000;
const ORDER_POLL_MS = 1000;
const POSITIONS_POLL_MS = 5000;
const MAX_BUFFER = 500;
const CONTENT_SCRIPT_VERSION = "2.1.7-safe-single-dropdown";
const DEFAULT_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/thunder-ticks";
const ORDERS_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/thunder-orders";
const POSITIONS_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/thunder-positions";

let buffer = [];
let mapping = {};                          // uuid -> { symbol, name, day_tradable }
let stats = { sent: 0, dropped: 0, lastFlush: 0, lastError: null };
let dispatchedToday = {};                  // orderId -> true (in-memory dedupe)
let inFlightOrders = {};                   // orderId -> true while preparing it
let failedOrders = {};                     // orderId -> true after a terminal local failure; prevents UI click loops
let lastOrderPoll = 0;
let lastOrderError = null;
let openPositions = {};                    // symbol(UPPER) -> { id, qty, tp, sl, entry }
let triggeredSells = {};                   // position_id -> ts (dedupe local sells)
let lastPositionsPoll = 0;
let lastPositionsError = null;

chrome.storage.local.get(["mapping", "stats"]).then((s) => {
  mapping = s.mapping || {};
  stats = { ...stats, ...(s.stats || {}) };
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === "ticks") {
    handleTicks(msg.payload);
  } else if (msg.type === "watchlist") {
    handleWatchlist(msg.payload);
  } else if (msg.type === "orderStatus") {
    // Content script reports back: { id, status, error_message? }
    reportOrderStatus(msg.payload).catch(() => {});
  } else if (msg.type === "getStatus") {
    chrome.storage.local.get(["autoExec", "maxPerDay", "egpPerTrade"]).then((cfg) => {
      sendResponse({
        mappedSymbols: Object.keys(mapping).length,
        buffered: buffer.length,
        stats,
        autoExec: cfg.autoExec === true,
        maxPerDay: cfg.maxPerDay ?? 3,
        egpPerTrade: cfg.egpPerTrade ?? 1000,
        executedToday: Object.keys(dispatchedToday).length,
        lastOrderPoll,
        lastOrderError,
      });
    });
    return true;
  } else if (msg.type === "clearMapping") {
    mapping = {};
    chrome.storage.local.set({ mapping });
    sendResponse({ ok: true });
    return true;
  } else if (msg.type === "runLocalOrderTest") {
    runLocalOrderTest().then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }
});

function handleWatchlist(arr) {
  let changed = false;
  for (const item of arr || []) {
    if (!item?.uuid || !item?.symbol) continue;
    const cur = mapping[item.uuid];
    if (!cur || cur.symbol !== item.symbol) {
      mapping[item.uuid] = {
        symbol: item.symbol,
        name: item.name || null,
        day_tradable: !!item.day_tradable,
      };
      changed = true;
    }
  }
  if (changed) chrome.storage.local.set({ mapping });
}

function handleTicks(arr) {
  if (!Array.isArray(arr)) return;
  for (const t of arr) {
    const m = mapping[t.uuid];
    if (!m) { stats.dropped++; continue; }
    buffer.push({ symbol: m.symbol, price: t.price, ts: t.ts, uuid: t.uuid });
    // Local sell-watcher: detect TP/SL hits instantly on the tick stream.
    checkLocalSell(m.symbol, t.price).catch(() => {});
  }
  if (buffer.length > MAX_BUFFER) buffer = buffer.slice(-MAX_BUFFER);
}

async function pollPositions() {
  const cfg = await chrome.storage.local.get(["token", "enabled"]);
  if (cfg.enabled === false) return;
  if (!cfg.token) { lastPositionsError = "no_token_configured"; return; }
  try {
    const res = await fetch(POSITIONS_ENDPOINT, {
      method: "GET",
      headers: { "x-thunder-token": cfg.token },
    });
    lastPositionsPoll = Date.now();
    if (!res.ok) { lastPositionsError = `positions_http_${res.status}`; return; }
    const json = await res.json();
    const list = Array.isArray(json?.positions) ? json.positions : [];
    const next = {};
    for (const p of list) {
      const sym = normalizeSymbol(p.symbol);
      if (!sym) continue;
      next[sym] = {
        id: p.id,
        qty: Number(p.quantity) || 0,
        tp: Number(p.target_price) || 0,
        sl: Math.max(Number(p.stop_loss) || 0, Number(p.trailing_stop) || 0),
        entry: Number(p.entry_price) || 0,
      };
    }
    openPositions = next;
    // Drop triggered entries for positions that are no longer open.
    for (const pid of Object.keys(triggeredSells)) {
      const stillOpen = Object.values(openPositions).some((p) => p.id === pid);
      if (!stillOpen) delete triggeredSells[pid];
    }
    lastPositionsError = null;
  } catch (e) {
    lastPositionsError = String(e?.message || e);
  }
}

async function checkLocalSell(symbol, price) {
  const sym = normalizeSymbol(symbol);
  const pos = openPositions[sym];
  if (!pos) return;
  if (triggeredSells[pos.id]) return;
  if (!(price > 0)) return;

  let reason = null;
  if (pos.tp > 0 && price >= pos.tp) reason = "target_hit";
  else if (pos.sl > 0 && price <= pos.sl) reason = "stop_hit";
  if (!reason) return;

  triggeredSells[pos.id] = Date.now();
  const { token } = await chrome.storage.local.get(["token"]);
  if (!token) return;
  try {
    await fetch(POSITIONS_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-thunder-token": token },
      body: JSON.stringify({ position_id: pos.id, reason, ref_price: price }),
    });
  } catch (e) {
    // Retry on next tick if it failed.
    delete triggeredSells[pos.id];
    lastPositionsError = "local_sell_post_failed: " + String(e?.message || e);
  }
}

async function flush() {
  if (buffer.length === 0) return;
  const { enabled, endpoint, token } = await chrome.storage.local.get(["enabled", "endpoint", "token"]);
  if (enabled === false) return;
  if (!token) { stats.lastError = "no_token_configured"; return; }
  const url = endpoint || DEFAULT_ENDPOINT;

  const batch = buffer.splice(0, buffer.length);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-thunder-token": token },
      body: JSON.stringify({ ticks: batch }),
    });
    if (!res.ok) {
      stats.lastError = `http_${res.status}`;
      buffer = batch.concat(buffer).slice(-MAX_BUFFER);
      return;
    }
    const json = await res.json().catch(() => ({}));
    stats.sent += (json?.inserted ?? batch.length);
    stats.lastFlush = Date.now();
    stats.lastError = null;
  } catch (e) {
    stats.lastError = String(e?.message || e);
    buffer = batch.concat(buffer).slice(-MAX_BUFFER);
  } finally {
    chrome.storage.local.set({ stats });
  }
}

// -------------------- Orders polling (Semi-Auto) --------------------

async function pollOrders() {
  const cfg = await chrome.storage.local.get(["token", "autoExec", "maxPerDay", "egpPerTrade", "enabled"]);
  if (cfg.enabled === false) return;
  if (cfg.autoExec !== true) return;
  if (!cfg.token) { lastOrderError = "no_token_configured"; return; }

  const max = cfg.maxPerDay ?? 3;
  if (Object.keys(dispatchedToday).length + Object.keys(inFlightOrders).length + Object.keys(failedOrders).length >= max) {
    lastOrderError = `daily_cap_reached_${max}`;
    return;
  }

  try {
    const res = await fetch(ORDERS_ENDPOINT, {
      method: "GET",
      headers: { "x-thunder-token": cfg.token },
    });
    lastOrderPoll = Date.now();
    if (!res.ok) { lastOrderError = `orders_http_${res.status}`; return; }
    const json = await res.json();
    const orders = Array.isArray(json?.orders) ? json.orders : [];
    lastOrderError = null;

    for (const o of orders) {
      if (dispatchedToday[o.id] || inFlightOrders[o.id] || failedOrders[o.id]) continue;
      if (!["pending", "opened"].includes(o.status)) continue;
      if (o.expires_at && new Date(o.expires_at).getTime() <= Date.now()) continue;

      // Reverse-lookup uuid from symbol
      const uuid = uuidForSymbol(o.symbol);
      if (!uuid) {
        lastOrderError = `uuid_not_mapped_${o.symbol} — افتح قائمة المراقبة في ثندر`;
        continue;
      }

      // Prefer server-provided qty; otherwise compute qty from configured EGP per trade.
      const egp = cfg.egpPerTrade ?? 1000;
      const price = Number(o.ref_price) || 0;
      const explicitQty = Number(o.qty);
      const qty = Number.isFinite(explicitQty) && explicitQty > 0 ? Math.floor(explicitQty) : (price > 0 ? Math.max(1, Math.floor(egp / price)) : 1);

      if (Object.keys(dispatchedToday).length + Object.keys(inFlightOrders).length + Object.keys(failedOrders).length >= max) break;
      inFlightOrders[o.id] = true;

      // Find a Thunder tab; open one if none.
      const tabs = await chrome.tabs.query({ url: ["https://web.thndr.app/*", "https://*.thndr.app/*"] });
      let tab = tabs[0];
      if (!tab) {
        tab = await chrome.tabs.create({ url: `https://web.thndr.app/ar/assets/${uuid}`, active: true });
      } else {
        await chrome.tabs.update(tab.id, { active: true, url: `https://web.thndr.app/ar/assets/${uuid}` });
      }

      prepareOrderInTab(tab.id, {
        type: "executeOrderV2",
        payload: {
          orderId: o.id,
          symbol: o.symbol,
          uuid,
          qty,
          side: o.side,
          refPrice: Number(o.ref_price) || 0,
          driftBps: 100, // 1% adverse move triggers warning
        },
      }).catch((e) => {
        lastOrderError = "prepare_failed: " + String(e?.message || e);
        failedOrders[o.id] = true;
        reportOrderStatus({ id: o.id, status: "error", error_message: lastOrderError });
      }).finally(() => {
        delete inFlightOrders[o.id];
      });
    }
  } catch (e) {
    lastOrderError = String(e?.message || e);
  }
}

function uuidForSymbol(symbol) {
  const want = normalizeSymbol(symbol);
  for (const [uuid, m] of Object.entries(mapping)) {
    if (normalizeSymbol(m?.symbol) === want) return uuid;
  }
  return null;
}

function normalizeSymbol(symbol) {
  return String(symbol || "").trim().toUpperCase();
}

async function prepareOrderInTab(tabId, message) {
  const result = await sendExecuteOrderWhenReady(tabId, message, 90_000);
  if (!result?.ok) throw new Error(result?.error || result?.stage || "prepare_not_ok");
  dispatchedToday[message.payload.orderId] = true;
  lastOrderError = null;
  return result;
}

function isSafeThndrUrl(url) {
  return /^https:\/\/([^/]+\.)?thndr\.app\//.test(String(url || ""));
}

async function waitForTabReady(tabId, timeoutMs = 25_000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab?.status === "complete" && /^https:\/\/([^/]+\.)?thndr\.app\//.test(tab.url || "")) return true;
    } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }
  return false;
}

async function runLocalOrderTest() {
  const entry = Object.entries(mapping).find(([uuid, m]) => uuid && m?.symbol);
  const [uuid, m] = entry || [null, { symbol: "TEST" }];
  const symbol = normalizeSymbol(m.symbol);
  const tabs = await chrome.tabs.query({ url: ["https://web.thndr.app/*", "https://*.thndr.app/*"] });
  const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
  let tab = activeTabs.find((t) => /^https:\/\/([^/]+\.)?thndr\.app\//.test(t.url || "")) || tabs[0];
  if (!tab && uuid) {
    tab = await chrome.tabs.create({ url: `https://web.thndr.app/ar/assets/${uuid}`, active: true });
  } else if (!tab) {
    tab = await chrome.tabs.create({ url: "https://web.thndr.app/ar", active: true });
  } else if (uuid) {
    await chrome.tabs.update(tab.id, { active: true, url: `https://web.thndr.app/ar/assets/${uuid}` });
  } else {
    await chrome.tabs.update(tab.id, { active: true });
  }
  const result = await sendExecuteOrderWhenReady(tab.id, {
      type: "executeOrderV2",
      payload: { orderId: `local-test-${Date.now()}`, symbol, uuid, qty: 1, side: "buy" },
    }, uuid ? 90_000 : 20_000);
  lastOrderError = null;
  return { ok: !!result?.ok, symbol, version: result?.version };
}

async function ensureContentScript(tabId) {
  try {
    const pong = await chrome.tabs.sendMessage(tabId, { type: "ping" });
    if (pong?.ok && pong.version === CONTENT_SCRIPT_VERSION) return true;
  } catch {}
  try {
    await chrome.scripting.executeScript({ target: { tabId, allFrames: false }, files: ["page-script.js"], world: "MAIN" });
  } catch {}
  try {
    await chrome.scripting.executeScript({ target: { tabId, allFrames: false }, files: ["content.js"], world: "ISOLATED" });
    await new Promise((r) => setTimeout(r, 200));
    return true;
  } catch (e) {
    throw new Error("content_script_inject_failed: " + String(e?.message || e));
  }
}

async function sendExecuteOrder(tabId, message) {
  await ensureContentScript(tabId);
  return chrome.tabs.sendMessage(tabId, message);
}

async function sendExecuteOrderWhenReady(tabId, message, timeoutMs = 12_000) {
  const start = Date.now();
  let lastErr = null;
  let lastResult = null;
  while (Date.now() - start < timeoutMs) {
    try {
      const res = await sendExecuteOrder(tabId, message);
      lastResult = res;
      if (res?.ok) return res;
      if (["order_type_not_selected", "qty_input_not_found", "qty_type_failed", "side_button_not_found", "side_button_no_form"].includes(res?.stage)) {
        return res;
      }
      if (res?.retryAfterNavigation) {
        if (res.thndrXUrl && isSafeThndrUrl(res.thndrXUrl)) {
          await chrome.tabs.update(tabId, { active: true, url: res.thndrXUrl });
        }
        tabId = await waitForLikelyTradingTab(tabId, 35_000);
        await waitForTabReady(tabId, 35_000);
        await new Promise((r) => setTimeout(r, 1800));
        continue;
      }
    } catch (e) {
      lastErr = e;
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error(lastErr?.message || lastResult?.stage || "thunder_page_not_ready");
}

async function waitForLikelyTradingTab(preferredTabId, timeoutMs = 35_000) {
  const start = Date.now();
  let best = preferredTabId;
  while (Date.now() - start < timeoutMs) {
    try {
      const preferred = await chrome.tabs.get(preferredTabId);
      if (isSafeThndrUrl(preferred?.url)) {
        best = preferred.id;
        if (isLikelyTradingUrl(preferred.url)) return preferred.id;
      }
    } catch {}
    try {
      const tabs = await chrome.tabs.query({ url: ["https://web.thndr.app/*", "https://*.thndr.app/*"] });
      const trading = tabs.find((t) => isLikelyTradingUrl(t.url));
      if (trading?.id) return trading.id;
      const active = tabs.find((t) => t.active && t.id);
      if (active?.id) best = active.id;
    } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }
  return best;
}

function isLikelyTradingUrl(url) {
  const u = String(url || "").toLowerCase();
  return isSafeThndrUrl(u) && (/thndrx|trader|trade|terminal|workspace|market/.test(u) || !/\/assets\//.test(u));
}

async function reportOrderStatus({ id, status, error_message }) {
  if (String(id || "").startsWith("local-test-")) return;
  const { token } = await chrome.storage.local.get(["token"]);
  if (!token) return;
  try {
    await fetch(ORDERS_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-thunder-token": token },
      body: JSON.stringify({ id, status, error_message }),
    });
  } catch {}
}

// Reset dispatchedToday at Cairo midnight (cheap: clear at 5am UTC)
function maybeResetDay() {
  const d = new Date();
  if (d.getUTCHours() === 5 && d.getUTCMinutes() < 5) { dispatchedToday = {}; failedOrders = {}; }
}

setInterval(flush, FLUSH_MS);
setInterval(pollOrders, ORDER_POLL_MS);
setInterval(pollPositions, POSITIONS_POLL_MS);
setInterval(maybeResetDay, 60_000);
