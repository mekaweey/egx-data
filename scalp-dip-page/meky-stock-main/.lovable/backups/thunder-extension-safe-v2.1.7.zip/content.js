/* Content script (ISOLATED world).
 * 1) Injects page-script.js into MAIN world (price/watchlist interception).
 * 2) Relays page-world messages to the background SW.
 * 3) Receives `executeOrder` from the background SW and runs a
 *    human-mimicry sequence to OPEN the buy form, fill quantity, and STOP
 *    at the review step. The user clicks the final confirm.
 *
 * Selectors are intentionally fuzzy (text-based) because Thunder's
 * production build uses hashed class names. If a step fails, we report
 * `error` back so the user gets a Telegram-style alert from the popup
 * and knows to act manually.
 */
(function () {
  const CONTENT_SCRIPT_VERSION = "2.1.7-safe-single-dropdown";
  if (window.__thunderContentHooked === CONTENT_SCRIPT_VERSION) return;
  window.__thunderContentHooked = CONTENT_SCRIPT_VERSION;
  const IS_TOP_FRAME = window.top === window;
  const pendingMainCommands = new Map();
  let activeExecution = null;
  let orderTypeAttemptLockedUntil = 0;

  // ---- inject MAIN-world script ----
  try {
    const s = document.createElement("script");
    s.src = chrome.runtime.getURL("page-script.js");
    s.async = false;
    (document.head || document.documentElement).appendChild(s);
    s.onload = () => s.remove();
  } catch (e) {
    console.error("[thunder-ext] inject failed", e);
  }

  window.addEventListener("message", (event) => {
    const data = event.data;
    if (data?.__thunderMainResult === true && pendingMainCommands.has(data.id)) {
      pendingMainCommands.get(data.id)(!!data.ok);
      pendingMainCommands.delete(data.id);
      return;
    }
    if (!data || data.__thunder !== true) return;
    if (event.source !== window) return;
    chrome.runtime.sendMessage({ type: data.type, payload: data.payload }).catch(() => {});
    // Also track latest price per uuid locally for the drift guard.
    if (data.type === "ticks" && Array.isArray(data.payload)) {
      for (const t of data.payload) {
        if (t?.uuid && t.price > 0) latestPriceByUuid[t.uuid] = { price: t.price, ts: Date.now() };
      }
    }
  });

  const latestPriceByUuid = {};
  let activeDriftWatcher = null;

  // ---- receive executeOrder from background ----
  // Only the top page is allowed to receive automation commands. Thunder uses
  // several frames; sending the test order to a hidden frame was the reason the
  // popup said “ok” while nothing visible happened.
  if (IS_TOP_FRAME) {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg?.type === "ping") {
        sendResponse({ ok: true, top: true, url: location.href, version: CONTENT_SCRIPT_VERSION });
        return false;
      }
      if (msg?.type === "executeOrder" || msg?.type === "executeOrderV2") {
        if (activeExecution && Date.now() - activeExecution.startedAt < 120_000) {
          sendResponse({ ok: false, top: true, version: CONTENT_SCRIPT_VERSION, stage: "automation_already_running" });
          return false;
        }
        activeExecution = { orderId: msg.payload?.orderId, startedAt: Date.now() };
        executeOrder(msg.payload).then((result) => {
          sendResponse({ ...(result || {}), top: true, version: CONTENT_SCRIPT_VERSION });
        }).catch((e) => {
          reportStatus(msg.payload.orderId, "error", "exception: " + String(e?.message || e));
          sendResponse({ ok: false, top: true, version: CONTENT_SCRIPT_VERSION, error: String(e?.message || e) });
        }).finally(() => {
          activeExecution = null;
        });
        return true;
      }
    });
  }

  function reportStatus(id, status, error_message) {
    chrome.runtime.sendMessage({ type: "orderStatus", payload: { id, status, error_message } }).catch(() => {});
  }

  function scanVisibleAssetLinks() {
    const uuidRe = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
    const symbolRe = /\b[A-Z]{2,6}\b/g;
    const out = [];
    const seen = new Set();
    for (const el of Array.from(document.querySelectorAll("a[href], [data-href]"))) {
      const href = el.getAttribute("href") || el.getAttribute("data-href") || "";
      const uuid = href.match(uuidRe)?.[0];
      if (!uuid || seen.has(uuid)) continue;
      let node = el;
      let text = "";
      for (let i = 0; node && i < 8; i++, node = node.parentElement) {
        const t = (node.textContent || "").trim();
        if (symbolRe.test(t) && t.length < 600) { text = t; break; }
        symbolRe.lastIndex = 0;
      }
      symbolRe.lastIndex = 0;
      const symbol = (text.match(symbolRe) || []).find((s) => !["EGP", "USD", "ETF"].includes(s));
      if (symbol) {
        seen.add(uuid);
        out.push({ uuid, symbol });
      }
    }
    if (out.length) chrome.runtime.sendMessage({ type: "watchlist", payload: out }).catch(() => {});
  }

  scanVisibleAssetLinks();
  setInterval(scanVisibleAssetLinks, 2000);

  // ---- human-mimicry helpers ----
  const rand = (min, max) => Math.floor(min + Math.random() * (max - min));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const humanDelay = (min = 600, max = 1400) => sleep(rand(min, max));

  function findByText(selector, text) {
    const list = Array.from(document.querySelectorAll(selector));
    const needle = String(text).trim();
    return list.find((el) => {
      const t = (el.textContent || "").trim();
      if (!t.includes(needle)) return false;
      // Prefer visible elements
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    }) || null;
  }

  function normalizeArabicText(text) {
    return String(text || "")
      .replace(/[\u064B-\u065F\u0670]/g, "")
      .replace(/[إأآا]/g, "ا")
      .replace(/ى/g, "ي")
      .replace(/ة/g, "ه")
      .replace(/\s+/g, " ")
      .trim();
  }

  function matchesAnyLabel(text, labels) {
    const t = normalizeArabicText(text).toLowerCase();
    return labels.some((label) => {
      const l = normalizeArabicText(label).toLowerCase();
      return t === l || t.includes(l);
    });
  }

  function isDisabled(el) {
    if (!el) return true;
    const style = getComputedStyle(el);
    return el.disabled || el.getAttribute("aria-disabled") === "true" || style.pointerEvents === "none";
  }

  function sideButtonCandidates(labels) {
    const selectors = "button, [role='button'], a, [tabindex], [onclick], div, span, p";
    const seen = new Set();
    return Array.from(document.querySelectorAll(selectors))
      .map((el) => {
        if (!isVisible(el)) return null;
        const text = cleanText(el);
        if (!text || text.length > 180 || !matchesAnyLabel(text, labels)) return null;
        if (/thndrx|thndr x|ثندرx|ثاندرx/i.test(normalizeArabicText(text))) return null;
        const directClickable = el.matches?.("button, [role='button'], a, [tabindex], [onclick]");
        const surface = directClickable ? el : clickableSurface(el);
        if (!surface || !isVisible(surface) || isDisabled(surface)) return null;
        const r = surface.getBoundingClientRect();
        if (r.width < 28 || r.height < 20) return null;
        if (r.width > Math.min(760, window.innerWidth - 12) && !directClickable) return null;
        if (seen.has(surface)) return null;
        seen.add(surface);
        const surfaceText = cleanText(surface);
        const exact = labels.some((label) => surfaceText === label || text === label) ? 0 : 20;
        const sidePenalty = /شراء|buy/i.test(labels.join(" ")) && /بيع|sell/i.test(surfaceText) ? 500 : 0;
        const tagScore = /button/i.test(surface.tagName) ? 0 : surface.getAttribute("role") === "button" ? 5 : 12;
        const sizeScore = Math.abs(r.height - 44) + Math.max(0, r.width - 260) / 8;
        return { el: surface, score: exact + tagScore + sizeScore + sidePenalty };
      })
      .filter(Boolean)
      .sort((a, b) => a.score - b.score)
      .map((item) => item.el);
  }

  // Broader search: any clickable-looking element containing the text.
  function findClickableByText(text) {
    return sideButtonCandidates([text])[0] || null;
  }

  function findSideButton(labels, { allowHeuristic = true } = {}) {
    return sideButtonCandidates(labels)[0] || (allowHeuristic ? findLikelyTradeButton(labels) : null) || null;
  }

  function findOpenThndrXButton() {
    const selectors = "a[href], button, [role='button'], [tabindex], [onclick], div, span";
    return Array.from(document.querySelectorAll(selectors))
      .map((el) => {
        if (!isVisible(el) || isDisabled(el)) return null;
        const text = cleanText(el);
        const normalized = normalizeArabicText(text).toLowerCase();
        const href = el.closest?.("a[href]")?.href || el.getAttribute?.("href") || "";
        const hay = `${normalized} ${String(href).toLowerCase()}`;
        const hasThndrX = hay.includes("thndrx") || hay.includes("thndr-x") || hay.includes("thndr x") || hay.includes("ثندرx") || hay.includes("ثاندرx");
        const surface = clickableSurface(el);
        if (!surface || !isVisible(surface) || isDisabled(surface)) return null;
        const r = surface.getBoundingClientRect();
        const isHeaderOpenButton = matchesAnyLabel(text, ["افتح", "Open"]) && r.top >= 0 && r.top <= 120 && r.height >= 34 && r.height <= 72 && r.width >= 70 && r.width <= 260;
        if (!hasThndrX && !isHeaderOpenButton) return null;
        if (r.width < 60 || r.height < 24 || r.width > Math.min(520, window.innerWidth - 12)) return null;
        const openScore = /افتح|open|launch|تداول|trade/i.test(hay) ? 0 : 80;
        const headerScore = isHeaderOpenButton ? 0 : 35;
        const tagScore = surface.matches?.("a[href], button, [role='button']") ? 0 : 18;
        return { el: surface, score: headerScore + openScore + tagScore + Math.abs(r.height - 44) + Math.max(0, r.width - 230) / 6 };
      })
      .filter(Boolean)
      .sort((a, b) => a.score - b.score)[0]?.el || null;
  }

  function safeThndrHref(el) {
    const href = el?.closest?.("a[href]")?.href || el?.getAttribute?.("href") || "";
    return /^https:\/\/([^/]+\.)?thndr\.app\//.test(href) ? href : "";
  }

  function thndrXOpenInstruction() {
    const trigger = findOpenThndrXButton();
    if (!trigger) return null;
    return { trigger, href: safeThndrHref(trigger) };
  }

  function scheduleThndrXClick(trigger) {
    setTimeout(() => {
      humanClick(trigger).catch(() => {});
    }, 120);
  }

  async function openThndrXWorkspaceIfPresent() {
    const trigger = await waitFor(() => findOpenThndrXButton(), { timeout: 5500, interval: 150 });
    if (!trigger) return false;
    debug("هفتح واجهة التداول ThndrX", "#f59e0b");
    const href = safeThndrHref(trigger);
    if (href) {
      window.location.assign(href);
    } else {
      await humanClick(trigger);
    }
    return !!(await waitFor(() => (
      findSideButton(["شراء", "Buy", "BUY", "بيع", "Sell", "SELL"]) ||
      findOrderTypeOpener() ||
      findQuantityInput() ||
      /thndrx|trade|trader|terminal/i.test(location.href)
    ), { timeout: 26000, interval: 300 }));
  }

  function findLikelyTradeButton(labels) {
    const wantSell = labels.some((label) => /بيع|Sell/i.test(label));
    const buttons = Array.from(document.querySelectorAll("button, [role='button'], a, [tabindex], [onclick], div, span"))
      .filter((el) => isVisible(el) && !isDisabled(el))
      .map((el) => ({ el, r: el.getBoundingClientRect(), text: cleanText(el), style: getComputedStyle(el) }))
      .filter(({ r }) => r.width >= 52 && r.height >= 28 && r.width <= Math.min(460, window.innerWidth - 16) && r.height <= 110)
      .filter(({ r }) => r.top < Math.max(620, window.innerHeight * 0.82))
      .filter(({ text }) => !/مراجعة|تأكيد|إلغاء|حفظ|اختار|السوق|Review|Confirm|Cancel|Save|Choose|Select/i.test(text));
    const exact = buttons.find(({ text }) => matchesAnyLabel(text, labels));
    if (exact) return clickableSurface(exact.el);
    return buttons
      .map((item) => {
        const dark = colorDarkness(item.style.backgroundColor) < 90 || colorDarkness(item.style.color) > 210;
        const hasPointer = item.style.cursor === "pointer" || item.el.matches?.("button, [role='button'], a, [tabindex], [onclick]");
        const sideScore = wantSell ? item.r.left : window.innerWidth - item.r.right;
        return { ...item, score: sideScore + (dark ? 0 : 35) + (hasPointer ? 0 : 25) + Math.abs(item.r.height - 44) };
      })
      .sort((a, b) => a.score - b.score)[0]?.el || null;
  }

  function colorDarkness(color) {
    const nums = String(color || "").match(/\d+(?:\.\d+)?/g)?.map(Number) || [];
    if (nums.length < 3) return 255;
    return (nums[0] * 0.299) + (nums[1] * 0.587) + (nums[2] * 0.114);
  }

  function isVisible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  }

  function cleanText(el) {
    return ((el?.textContent || "") + " " + (el?.value || "") + " " + (el?.getAttribute?.("placeholder") || "") + " " + (el?.getAttribute?.("aria-label") || "") + " " + (el?.getAttribute?.("title") || "") + " " + (el?.getAttribute?.("data-testid") || ""))
      .replace(/\s+/g, " ")
      .trim();
  }

  function findSmallTextElement(labels) {
    const els = Array.from(document.querySelectorAll("body *"));
    return els
      .filter((el) => {
        if (!isVisible(el)) return false;
        const text = cleanText(el);
        if (text.length > 35) return false;
        return labels.some((label) => text === label || text.includes(label));
      })
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return (ar.width * ar.height) - (br.width * br.height);
      })[0] || null;
  }

  function clickableSurface(el) {
    if (!el) return null;
    const clickable = el.closest?.("button, [role='button'], [role='combobox'], [role='option'], a, li, input, label, [tabindex], [onclick]");
    if (clickable && isVisible(clickable)) return clickable;
    let cur = el;
    let best = el;
    for (let depth = 0; cur && depth < 7; depth++, cur = cur.parentElement) {
      if (!isVisible(cur)) continue;
      const r = cur.getBoundingClientRect();
      const style = getComputedStyle(cur);
      if ((style.cursor === "pointer" || typeof cur.onclick === "function") && r.width >= 28 && r.height >= 20 && r.width <= Math.min(760, window.innerWidth - 12) && r.height <= 180) best = cur;
    }
    if (best && isVisible(best)) return best;
    return el;
  }

  function findOrderTypeOpener() {
    const labelEl = findSmallTextElement(["نوع الطلب", "Order type"]);

    // Best path: anchor on the exact "نوع الطلب" label, then choose the field
    // horizontally aligned with it. This avoids clicking unrelated "اختار" fields.
    if (labelEl) {
      const lr = labelEl.getBoundingClientRect();
      let scope = labelEl.parentElement;
      for (let depth = 0; scope && depth < 7; depth++, scope = scope.parentElement) {
        const sr = scope.getBoundingClientRect();
        if (sr.width < 140 || sr.height > 360) continue;
        const candidates = Array.from(scope.querySelectorAll("button, [role='button'], [role='combobox'], input, div, span"))
          .filter((el) => el !== labelEl && !el.contains(labelEl) && !labelEl.contains(el))
          .map((el) => ({ el, r: el.getBoundingClientRect(), text: cleanText(el) }))
          .filter(({ el, r, text }) => {
            if (!isVisible(el)) return false;
            if (r.height < 26 || r.height > 82 || r.width < 54 || r.width > Math.min(360, window.innerWidth - 24)) return false;
            if (Math.abs((r.top + r.bottom) / 2 - (lr.top + lr.bottom) / 2) > 55) return false;
            if (/نوع الطلب|Order type/i.test(text)) return false;
            return !text || text.length <= 70 || /اختار|اختر|سعر السوق|سعر محدد|Select|Choose|Market|Limit/i.test(text);
          })
          .sort((a, b) => {
            const ay = Math.abs((a.r.top + a.r.bottom) / 2 - (lr.top + lr.bottom) / 2);
            const by = Math.abs((b.r.top + b.r.bottom) / 2 - (lr.top + lr.bottom) / 2);
            const ax = Math.abs((a.r.left + a.r.right) / 2 - (lr.left + lr.right) / 2);
            const bx = Math.abs((b.r.left + b.r.right) / 2 - (lr.left + lr.right) / 2);
            const aText = /اختار|اختر|سعر السوق|سعر محدد|Select|Choose|Market|Limit/i.test(a.text) ? 0 : 20;
            const bText = /اختار|اختر|سعر السوق|سعر محدد|Select|Choose|Market|Limit/i.test(b.text) ? 0 : 20;
            return (ay + ax / 6 + aText) - (by + bx / 6 + bText);
          });
        if (candidates[0]) return clickableSurface(candidates[0].el);
      }
    }

    // Fallback: short visible select trigger. Kept second on purpose so it
    // cannot steal focus from the actual order-type row.
    const fallback = Array.from(document.querySelectorAll("button, [role='button'], [role='combobox'], div, span, input"))
      .find((el) => {
        if (!isVisible(el)) return false;
        const r = el.getBoundingClientRect();
        const text = cleanText(el);
        if (r.height < 26 || r.height > 82 || r.width < 54 || r.width > 360 || text.length > 70) return false;
        return /اختار|اختر|Select|Choose|سعر السوق|Market/i.test(text);
      });
    return clickableSurface(fallback);
  }

  function optionRootFor(el, labels) {
    let cur = el;
    let best = el;
    for (let depth = 0; cur && depth < 6; depth++, cur = cur.parentElement) {
      if (!isVisible(cur)) continue;
      const text = cleanText(cur);
      if (!labels.some((label) => text.includes(label))) break;
      if (/سعر محدد|الطلبات المتقدمة|Limit|Advanced/i.test(text) && /سعر السوق|Market|سوق/i.test(text)) break;
      const r = cur.getBoundingClientRect();
      if (r.height >= 28 && r.height <= 120 && r.width >= 80) best = cur;
    }
    return clickableSurface(best);
  }

  function snapshotVisibleElements() {
    return new WeakSet(Array.from(document.querySelectorAll("body *")).filter((el) => {
      try { return isVisible(el); } catch { return false; }
    }));
  }

  function findShortTextOption(labels, excludeRoot) {
    return findShortTextOptions(labels, excludeRoot)[0] || null;
  }

  function findShortTextOptions(labels, excludeRoot) {
    // Find the real opened menu option, not the closed "اختار" trigger. Some
    // dropdowns keep their option nodes mounted with opacity:0, so visibility
    // alone is not enough; the center point must also be hit-testable.
    const opener = excludeRoot || findOrderTypeOpener();
    const openerRect = opener?.getBoundingClientRect?.();
    const seen = new Set();
    const options = [];
    const selectors = "[role='option'], [role='menuitem'], [role='menuitemradio'], [role='listbox'] *, [data-radix-popper-content-wrapper] *, li[tabindex], li[role], [data-value], li, button, [role='button'], div, span, p";

    for (const raw of Array.from(document.querySelectorAll(selectors))) {
      const candidates = [
        raw.closest?.("[role='option'], [role='menuitem'], [role='menuitemradio'], li[tabindex], li[role], [data-value], li, button"),
        raw,
      ];
      for (const el of candidates) {
        if (!el || seen.has(el)) continue;
        seen.add(el);
        const score = marketOptionScore(el, labels, opener, openerRect);
        if (score < Infinity) options.push({ el, score });
      }
    }

    return options.sort((a, b) => a.score - b.score).map((item) => item.el);
  }

  function marketOptionScore(el, labels, opener, openerRect) {
    if (!el || !isVisible(el)) return Infinity;
    if (opener && (el === opener || opener.contains(el) || el.contains(opener))) return Infinity;
    if (isDisabled(el)) return Infinity;
    const style = getComputedStyle(el);
    if (Number(style.opacity || "1") < 0.08 || style.pointerEvents === "none") return Infinity;
    const r = el.getBoundingClientRect();
    if (r.height < 12 || r.height > 180 || r.width < 24 || r.width > Math.min(820, window.innerWidth - 12)) return Infinity;
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    if (cx < 0 || cy < 0 || cx > window.innerWidth || cy > window.innerHeight) return Infinity;
    const hit = document.elementFromPoint(cx, cy);
    if (!hit || !(el === hit || el.contains(hit) || hit.contains(el))) return Infinity;

    const text = cleanText(el);
    if (!text || text.length > 180) return Infinity;
    const normalizedText = normalizeArabicText(text).toLowerCase();
    const hasMarket = labels.some((label) => normalizedText.includes(normalizeArabicText(label).toLowerCase()));
    if (!hasMarket) return Infinity;
    if (/سعر محدد|limit|الطلبات المتقدمه|advanced/i.test(normalizedText)) return Infinity;

    const exact = labels.some((label) => normalizedText === normalizeArabicText(label).toLowerCase()) ? 0 : 24;
    const semantic = el.matches?.("[role='option'], [role='menuitem'], [role='menuitemradio'], li, [data-value]") ? 0 : 18;
    const nearOpener = openerRect
      ? Math.abs(cx - (openerRect.left + openerRect.width / 2)) / 8 + Math.max(0, r.top - openerRect.bottom) / 4
      : 35;
    const compact = Math.max(0, r.height - 54) + Math.max(0, r.width - 260) / 10;
    return exact + semantic + nearOpener + compact;
  }

  function orderTypeTriggerShowsMarket() {
    const opener = findOrderTypeOpener();
    if (!opener || !isVisible(opener)) return false;
    const text = ((opener.textContent || "") + " " + (opener.value || "")).replace(/\s+/g, " ").trim();
    return /سعر السوق|Market/i.test(text);
  }

  function findQuantityInput() {
    const orderTypeOpener = findOrderTypeOpener();
    const candidates = Array.from(document.querySelectorAll("input:not([type='hidden']), textarea"));
    const visible = candidates.filter((el) => {
      if (el === orderTypeOpener || orderTypeOpener?.contains?.(el) || el.closest?.("[role='combobox']")) return false;
      if (el.disabled || el.readOnly || !isVisible(el)) return false;
      const hay = `${el.type || ""} ${el.inputMode || ""} ${el.name || ""} ${el.id || ""} ${el.placeholder || ""} ${el.getAttribute("aria-label") || ""}`;
      if (/اختار|اختر|select|choose|order.?type|نوع الطلب/i.test(hay)) return false;
      return true;
    });
    const preferred = visible.find((el) => {
      const hay = `${el.type || ""} ${el.inputMode || ""} ${el.name || ""} ${el.id || ""} ${el.placeholder || ""} ${el.getAttribute("aria-label") || ""}`;
      return /number|numeric|qty|quantity|shares|كمية|عدد/i.test(hay);
    });
    return preferred || (visible.length === 1 ? visible[0] : null);
  }

  async function ensureMarketOrderType() {
    // If the dropdown trigger already shows "سعر السوق", nothing to do.
    if (orderTypeTriggerShowsMarket()) return true;
    if (Date.now() < orderTypeAttemptLockedUntil) {
      debug("❌ توقفت بأمان: نوع الطلب محتاج اختيار يدوي", "#ef4444");
      return false;
    }

    const opener = findOrderTypeOpener();
    if (!opener) { debug("❌ مش لاقي قائمة نوع الطلب", "#ef4444"); return false; }
    debug("بفتح قائمة نوع الطلب", "#3b82f6");

    // Native <select>: set value directly, no dropdown toggling.
    const nativeSelect = opener.tagName === "SELECT" ? opener : opener.querySelector?.("select");
    if (nativeSelect) {
      const opt = Array.from(nativeSelect.options || []).find((o) =>
        /سعر السوق|Market|سوق/i.test(`${o.textContent || ""} ${o.value || ""}`),
      );
      if (!opt) { debug("❌ select بدون خيار سعر السوق", "#ef4444"); return false; }
      const proto = Object.getPrototypeOf(nativeSelect);
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (setter) setter.call(nativeSelect, opt.value); else nativeSelect.value = opt.value;
      nativeSelect.dispatchEvent(new Event("input", { bubbles: true }));
      nativeSelect.dispatchEvent(new Event("change", { bubbles: true }));
      return !!(await waitFor(() => orderTypeTriggerShowsMarket(), { timeout: 2500, interval: 120 }));
    }

    // Custom dropdown. Open once, then choose from the visible popup only.
    // If we cannot identify a clickable option, abort safely instead of
    // clicking the opener again and toggling it open/closed forever.
    const LABELS = ["سعر السوق", "Market", "سوق"];
    const openerRect = opener.getBoundingClientRect();
    orderTypeAttemptLockedUntil = Date.now() + 60_000;
    await preciseClick(opener);
    await humanDelay(250, 420);

    const option = await waitFor(() => findShortTextOption(LABELS, opener), { timeout: 2500, interval: 120 });
    debug("بختار سعر السوق", "#3b82f6");

    // Choose from the already-open popup using MAIN-world pointer + keyboard
    // semantics. Do not click the opener again under any failure mode.
    const mainSelected = await mainWorldSelectVisibleText(LABELS, openerRect);
    if (mainSelected) {
      const confirmed = await waitFor(() => orderTypeTriggerShowsMarket(), { timeout: 2600, interval: 120 });
      if (confirmed) { orderTypeAttemptLockedUntil = 0; await humanDelay(300, 600); return true; }
    }

    const optionList = findShortTextOptions(LABELS, opener).slice(0, 2);
    for (const opt of optionList.length ? optionList : (option ? [option] : [])) {
      if (!isVisible(opt)) continue;
      await preciseClick(opt);
      const confirmed = await waitFor(() => orderTypeTriggerShowsMarket(), { timeout: 1600, interval: 120 });
      if (confirmed) { orderTypeAttemptLockedUntil = 0; await humanDelay(300, 600); return true; }
      if (!findShortTextOption(LABELS, opener)) break;
    }

    debug("❌ نوع الطلب لسه مش سعر السوق", "#ef4444");
    try { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); } catch {}
    return false;
  }

  function findFirstVisibleAssetRow() {
    const symbolRe = /\b[A-Z]{2,6}\b/;
    const bad = new Set(["EGP", "USD", "ETF", "BUY", "SELL"]);
    const smallTextEls = Array.from(document.querySelectorAll("body *")).filter((el) => {
      const text = (el.textContent || "").trim();
      if (!symbolRe.test(text) || text.length > 80) return false;
      const symbol = text.match(symbolRe)?.[0];
      if (!symbol || bad.has(symbol)) return false;
      const r = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && style.visibility !== "hidden" && style.display !== "none";
    });

    for (const symbolEl of smallTextEls) {
      let node = symbolEl;
      for (let depth = 0; node && depth < 8; depth++, node = node.parentElement) {
        const r = node.getBoundingClientRect();
        const text = (node.textContent || "").trim();
        if (r.width > Math.min(420, window.innerWidth * 0.35) && r.height >= 44 && r.height <= 170 && text.includes("سهم")) {
          return node;
        }
      }
    }
    return findClickableByText("سهم") || findClickableByText("Stock");
  }

  async function openFirstAssetFromCurrentList() {
    const row = findFirstVisibleAssetRow();
    if (!row) return false;
    debug("مش على صفحة سهم — هفتح أول صف سهم ظاهر", "#f59e0b");
    await humanClick(row);
    return true;
  }

  // Visible debug banner so user can see progress on the Thunder page itself.
  let debugBanner = null;
  function debug(msg, color = "#3b82f6") {
    console.info("[thunder-ext]", msg);
    try {
      if (!debugBanner) {
        debugBanner = document.createElement("div");
        debugBanner.style.cssText = "position:fixed;bottom:12px;left:12px;z-index:2147483647;padding:8px 14px;border-radius:8px;font-family:system-ui,sans-serif;font-size:13px;font-weight:600;direction:rtl;box-shadow:0 6px 24px rgba(0,0,0,0.25);color:#fff;max-width:380px;";
        document.body.appendChild(debugBanner);
      }
      debugBanner.style.background = color;
      debugBanner.textContent = "[ثندر] " + msg;
    } catch {}
  }

  async function waitFor(predicateFn, { timeout = 8000, interval = 200 } = {}) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      try {
        const v = predicateFn();
        if (v) return v;
      } catch {}
      await sleep(interval);
    }
    return null;
  }

  async function humanClick(el) {
    if (!el) return false;
    el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    await humanDelay(180, 420);

    const clickable = clickableSurface(el) || el;
    const r = clickable.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const points = [
      [r.left + r.width / 2, r.top + r.height / 2],
      [r.left + Math.min(r.width - 6, Math.max(6, r.width * 0.30)), r.top + r.height / 2],
      [r.left + Math.min(r.width - 6, Math.max(6, r.width * 0.70)), r.top + r.height / 2],
    ];

    let didClick = false;
    for (const [x, y] of points) {
      if (x < 0 || y < 0 || x > window.innerWidth || y > window.innerHeight) continue;
      didClick = (await mainWorldClickAt(x, y)) || didClick;
      await humanDelay(70, 140);
      const topEl = document.elementFromPoint(x, y);
      const targets = clickTargets(topEl || clickable, clickable);
      for (const target of targets) {
        await dispatchSafeClick(target, x, y);
        didClick = true;
        await humanDelay(80, 160);
      }
    }
    try { if (typeof clickable.click === "function") { clickable.click(); didClick = true; } } catch {}
    return didClick;
  }

  // Single, well-targeted click. Use for toggles (dropdown triggers, tabs)
  // where humanClick's multi-point click would toggle them closed again.
  async function singleClick(el) {
    if (!el) return false;
    const clickable = clickableSurface(el) || el;
    clickable.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    await humanDelay(140, 280);
    const r = clickable.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const x = r.left + r.width / 2;
    const y = r.top + r.height / 2;
    if (x < 0 || y < 0 || x > window.innerWidth || y > window.innerHeight) return false;
    let didClick = await mainWorldClickAt(x, y);
    if (!didClick) {
      const topEl = document.elementFromPoint(x, y) || clickable;
      const target = topEl.closest?.("button, [role='button'], [role='combobox'], [role='option'], a, li, [tabindex], [onclick]") || topEl;
      await dispatchSafeClick(target, x, y);
      didClick = true;
    }
    return didClick;
  }

  // One physical click only. Dropdowns toggle on every extra click, so this
  // avoids React-handler fan-out and never calls fallback .click().
  async function preciseClick(el) {
    if (!el) return false;
    const clickable = clickableSurface(el) || el;
    clickable.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    await humanDelay(140, 260);
    const r = clickable.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const x = r.left + r.width / 2;
    const y = r.top + r.height / 2;
    if (x < 0 || y < 0 || x > window.innerWidth || y > window.innerHeight) return false;
    const mainClicked = await mainWorldPreciseClickAt(x, y);
    if (mainClicked) return true;
    await dispatchSafeClick(clickable, x, y);
    return true;
  }

  function mainWorldCommand(action, payload, timeout = 1200) {
    return new Promise((resolve) => {
      const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
      const timer = setTimeout(() => {
        pendingMainCommands.delete(id);
        resolve(false);
      }, timeout);
      pendingMainCommands.set(id, (ok) => {
        clearTimeout(timer);
        resolve(!!ok);
      });
      window.postMessage({ __thunderMainCommand: true, id, action, payload }, "*");
    });
  }

  function mainWorldClickAt(x, y) {
    return mainWorldCommand("clickAt", { x, y }, 1400);
  }

  function mainWorldPreciseClickAt(x, y) {
    return mainWorldCommand("preciseClickAt", { x, y }, 1400);
  }

  function mainWorldSelectVisibleText(labels, avoidRect) {
    return mainWorldCommand("selectVisibleText", {
      labels,
      avoidRect: avoidRect ? { left: avoidRect.left, top: avoidRect.top, right: avoidRect.right, bottom: avoidRect.bottom, width: avoidRect.width, height: avoidRect.height } : null,
    }, 1800);
  }

  function mainWorldTypeAt(input, text) {
    const r = input?.getBoundingClientRect?.();
    if (!r || r.width <= 0 || r.height <= 0) return Promise.resolve(false);
    return mainWorldCommand("typeAt", { x: r.left + r.width / 2, y: r.top + r.height / 2, text }, 1400);
  }

  function clickTargets(hit, fallback) {
    const out = [];
    const add = (node) => {
      if (node && node.nodeType === 1 && !out.includes(node) && isVisible(node) && !isDisabled(node)) out.push(node);
    };
    add(hit);
    add(hit?.closest?.("button, [role='button'], a, [tabindex], [onclick]"));
    add(fallback);
    let cur = hit?.parentElement;
    for (let i = 0; cur && i < 4; i++, cur = cur.parentElement) {
      const style = getComputedStyle(cur);
      if (cur === fallback || cur.matches?.("button, [role='button'], a, [tabindex], [onclick]") || style.cursor === "pointer") add(cur);
    }
    return out;
  }

  async function dispatchSafeClick(target, x, y) {
    try { target.focus?.({ preventScroll: true }); } catch {}
    const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: 1, detail: 1 };
    if (typeof PointerEvent !== "undefined") {
      target.dispatchEvent(new PointerEvent("pointerover", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true }));
      target.dispatchEvent(new PointerEvent("pointermove", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true }));
      target.dispatchEvent(new PointerEvent("pointerdown", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true }));
      await humanDelay(35, 90);
      target.dispatchEvent(new PointerEvent("pointerup", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: 0 }));
    }
    target.dispatchEvent(new MouseEvent("mouseover", base));
    target.dispatchEvent(new MouseEvent("mousemove", base));
    target.dispatchEvent(new MouseEvent("mousedown", base));
    await humanDelay(35, 90);
    target.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
    target.dispatchEvent(new MouseEvent("click", { ...base, buttons: 0 }));
  }

  async function humanType(input, text) {
    if (!input) return false;
    input.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    await humanDelay(120, 260);
    const mainTyped = await mainWorldTypeAt(input, text);
    if (mainTyped) return true;
    input.focus();
    // Clear via React-friendly setter
    const proto = Object.getPrototypeOf(input);
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(input, "");
    input.dispatchEvent(new Event("input", { bubbles: true }));
    await humanDelay(150, 350);

    let buf = "";
    for (const ch of String(text)) {
      buf += ch;
      if (setter) setter.call(input, buf);
      input.dispatchEvent(new Event("input", { bubbles: true }));
      await sleep(rand(80, 200));
    }
    input.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  // ---- order executor (Semi-Auto) ----
  async function executeOrder({ orderId, symbol, uuid, qty, side, refPrice, driftBps }) {
    reportStatus(orderId, "opened");
    debug(`بدأ التنفيذ — ${symbol} كمية ${qty}`, "#3b82f6");

    const isSell = String(side || "buy").toLowerCase() === "sell";
    const primaryLabels = isSell
      ? ["بيع", "Sell"]
      : ["شراء", "Buy"];

    // Step 0: The regular asset/profile page only shows charts/statistics and
    // an "افتح ThndrX" entry point. Open the trading workspace first, then look
    // for Buy/Sell there. This is safe: we still stop before final review.
    await humanDelay(800, 1600);
    if (!findSideButton(primaryLabels, { allowHeuristic: false })) {
      const openX = thndrXOpenInstruction();
      if (openX) {
        debug("لازم أفتح ThndrX الأول", "#f59e0b");
        if (!openX.href) await humanClick(openX.trigger);
        return { ok: false, retryAfterNavigation: true, stage: "open_thndrx_required", thndrXUrl: openX.href || null };
      }
    }

    // Step 1: wait for the trading workspace to render the buy/sell button matching `side`.
    if (!findSideButton(primaryLabels)) {
      const openedFromList = await openFirstAssetFromCurrentList();
      if (openedFromList) await humanDelay(2500, 4500);
      if (!findSideButton(primaryLabels, { allowHeuristic: false })) {
        const openX = thndrXOpenInstruction();
        if (openX) {
          debug("لازم أفتح ThndrX الأول", "#f59e0b");
          if (!openX.href) await humanClick(openX.trigger);
          return { ok: false, retryAfterNavigation: true, stage: "open_thndrx_required", thndrXUrl: openX.href || null };
        }
      }
    }
    debug("بدور على زرار " + primaryLabels[0], "#3b82f6");
    let clickedSide = false;
    let formOpened = null;
    for (let attempt = 1; attempt <= 6 && !formOpened; attempt++) {
      const sideBtn = await waitFor(() => findSideButton(primaryLabels), { timeout: attempt === 1 ? 10_000 : 2500, interval: 150 });
      if (!sideBtn) continue;
      debug(`لقيت الزرار — محاولة ضغط ${attempt}/6`, "#10b981");
      clickedSide = (await humanClick(sideBtn)) || clickedSide;
      formOpened = await waitFor(() => findOrderTypeOpener() || findQuantityInput(), { timeout: 3500, interval: 150 });
      if (!formOpened) await humanDelay(450, 800);
    }

    if (!clickedSide) {
      reportStatus(orderId, "error", `${isSell ? "sell" : "buy"}_button_not_found — افتح السهم يدوياً`);
      debug(`❌ مفيش زرار ${primaryLabels[0]} — افتح السهم يدوياً`, "#ef4444");
      return { ok: false, stage: "side_button_not_found" };
    }
    if (!formOpened) {
      reportStatus(orderId, "error", `${isSell ? "sell" : "buy"}_button_no_form — الزرار اتضغط بس نافذة الطلب مفتحتش`);
      debug(`❌ الزرار اتضغط بس نافذة الطلب مفتحتش`, "#ef4444");
      return { ok: false, stage: "side_button_no_form" };
    }
    await humanDelay(500, 900);

    // Step 2: ensure order type = market. Abort cleanly if we can't.
    const typeOk = await ensureMarketOrderType();
    if (!typeOk) {
      reportStatus(orderId, "error", "order_type_not_selected — اختار 'سعر السوق' يدوياً");
      return { ok: false, stage: "order_type_not_selected" };
    }

    // Step 3: fill quantity input.
    const qtyInput = await waitFor(() => findQuantityInput(), { timeout: 7000 });

    if (!qtyInput) {
      reportStatus(orderId, "error", "qty_input_not_found");
      debug("❌ مفيش خانة كمية", "#ef4444");
      return { ok: false, stage: "qty_input_not_found" };
    }
    debug("بكتب الكمية: " + qty, "#10b981");
    const ok = await humanType(qtyInput, String(qty));
    if (!ok) {
      reportStatus(orderId, "error", "qty_type_failed");
      return { ok: false, stage: "qty_type_failed" };
    }

    await humanDelay(800, 1500);

    // Step 4: STOP HERE. Do NOT click "مراجعة الطلب" / confirm.
    // Highlight the review button so the user can see it.
    const reviewBtn = findByText("button", "مراجعة الطلب") || findByText("button", "مراجعة") || findByText("button", "Review");
    if (reviewBtn) {
      try {
        reviewBtn.style.outline = "3px solid #f59e0b";
        reviewBtn.style.boxShadow = "0 0 16px rgba(245,158,11,0.7)";
        reviewBtn.scrollIntoView({ block: "center", behavior: "smooth" });
      } catch {}
    }

    reportStatus(orderId, "prepared");
    debug(`✓ جاهز — راجع واضغط 'مراجعة الطلب' بنفسك`, "#10b981");
    console.info(`[thunder-ext] ${isSell ? "SELL" : "BUY"} prepared: ${symbol} qty=${qty} — اضغط مراجعة الطلب`);

    // ---- Drift Guard: keep watching the price; warn if it moves against us. ----
    startDriftGuard({ orderId, symbol, uuid, side, isSell, refPrice, driftBps, reviewBtn });
    return { ok: true, stage: "prepared", version: CONTENT_SCRIPT_VERSION };
  }

  function startDriftGuard({ orderId, symbol, uuid, isSell, refPrice, driftBps, reviewBtn }) {
    if (activeDriftWatcher) { clearInterval(activeDriftWatcher); activeDriftWatcher = null; }
    const ref = Number(refPrice) || 0;
    if (!ref || !uuid) return;
    const thresh = (Number(driftBps) || 100) / 10000; // bps → fraction
    const startedAt = Date.now();
    let warned = false;

    const banner = document.createElement("div");
    banner.style.cssText = "position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:2147483647;padding:10px 16px;border-radius:8px;font-family:system-ui,sans-serif;font-size:14px;font-weight:600;direction:rtl;box-shadow:0 6px 24px rgba(0,0,0,0.25);transition:all .2s;background:#10b981;color:#fff;";
    banner.textContent = `حارس السعر شغّال — مرجع: ${ref.toFixed(3)}`;
    document.body.appendChild(banner);

    activeDriftWatcher = setInterval(() => {
      // Auto-stop after 5 minutes or if user navigated away.
      if (Date.now() - startedAt > 5 * 60_000) { stop(); return; }
      const cur = latestPriceByUuid[uuid];
      if (!cur || Date.now() - cur.ts > 15_000) {
        banner.style.background = "#6b7280";
        banner.textContent = "حارس السعر — لا توجد أسعار حديثة";
        return;
      }
      const price = cur.price;
      const drift = (price - ref) / ref; // + = price up, - = price down
      const adverse = isSell ? -drift : drift; // for buy: price↑ bad; for sell: price↓ bad
      const pct = (drift * 100).toFixed(2);

      if (adverse > thresh) {
        // Bad drift — scream.
        if (!warned) {
          warned = true;
          try { if (reviewBtn) { reviewBtn.style.outline = "3px solid #ef4444"; reviewBtn.style.boxShadow = "0 0 24px rgba(239,68,68,0.9)"; } } catch {}
          beep();
          reportStatus(orderId, "error", `price_drift_${isSell ? "down" : "up"}_${pct}%`);
        }
        banner.style.background = "#ef4444";
        banner.textContent = `⚠️ السعر اتغير ${pct}% — متدوسش! (${price.toFixed(3)} مقابل ${ref.toFixed(3)})`;
      } else if (Math.abs(drift) > thresh / 2) {
        banner.style.background = "#f59e0b";
        banner.textContent = `تنبيه: السعر تحرك ${pct}% (${price.toFixed(3)})`;
      } else {
        banner.style.background = "#10b981";
        banner.textContent = `حارس السعر شغّال — ${price.toFixed(3)} (${pct}%)`;
      }
    }, 1000);

    function stop() {
      if (activeDriftWatcher) { clearInterval(activeDriftWatcher); activeDriftWatcher = null; }
      try { banner.remove(); } catch {}
    }
  }

  function beep() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "square"; o.frequency.value = 880;
      g.gain.value = 0.15;
      o.connect(g); g.connect(ctx.destination);
      o.start(); setTimeout(() => { o.stop(); ctx.close(); }, 400);
    } catch {}
  }
})();
