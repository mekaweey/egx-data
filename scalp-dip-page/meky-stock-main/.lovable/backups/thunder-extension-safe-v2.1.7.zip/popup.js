const DEFAULT_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/thunder-ticks";

async function load() {
  const s = await chrome.storage.local.get(["token", "endpoint", "enabled", "autoExec", "maxPerDay", "egpPerTrade"]);
  document.getElementById("token").value = s.token || "";
  document.getElementById("endpoint").value = s.endpoint || DEFAULT_ENDPOINT;
  document.getElementById("egpPerTrade").value = s.egpPerTrade ?? 1000;
  document.getElementById("maxPerDay").value = s.maxPerDay ?? 3;
  setToggle(s.enabled !== false);
  setAutoExec(s.autoExec === true);
}

function setToggle(on) {
  const btn = document.getElementById("toggle");
  btn.textContent = on ? "شغّال ✓" : "متوقف ✗";
  btn.className = on ? "toggle-on" : "toggle-off";
  btn.dataset.on = on ? "1" : "0";
}
function setAutoExec(on) {
  const btn = document.getElementById("autoExecBtn");
  btn.textContent = on ? "Semi-Auto: شغّال ✓" : "Semi-Auto: متوقف ✗";
  btn.className = on ? "toggle-on" : "toggle-off";
  btn.dataset.on = on ? "1" : "0";
}

document.getElementById("save").onclick = async () => {
  const token = document.getElementById("token").value.trim();
  const endpoint = document.getElementById("endpoint").value.trim() || DEFAULT_ENDPOINT;
  const egpPerTrade = Math.max(100, Number(document.getElementById("egpPerTrade").value) || 1000);
  const maxPerDay = Math.max(1, Math.min(10, Number(document.getElementById("maxPerDay").value) || 3));
  await chrome.storage.local.set({ token, endpoint, egpPerTrade, maxPerDay });
  const btn = document.getElementById("save");
  btn.textContent = "اتحفظ ✓";
  setTimeout(() => (btn.textContent = "حفظ"), 1200);
};

document.getElementById("toggle").onclick = async () => {
  const on = document.getElementById("toggle").dataset.on === "1";
  await chrome.storage.local.set({ enabled: !on });
  setToggle(!on);
};
document.getElementById("autoExecBtn").onclick = async () => {
  const on = document.getElementById("autoExecBtn").dataset.on === "1";
  if (!on) {
    const ok = confirm("تأكيد: الـ Extension هيفتح ثاندر ويملي بيانات الشراء تلقائياً.\nانت اللي هتضغط 'مراجعة الطلب' في الآخر.\nموافق؟");
    if (!ok) return;
  }
  await chrome.storage.local.set({ autoExec: !on });
  setAutoExec(!on);
};

document.getElementById("localTest").onclick = async () => {
  const btn = document.getElementById("localTest");
  btn.textContent = "جاري الاختبار...";
  try {
    const res = await chrome.runtime.sendMessage({ type: "runLocalOrderTest" });
    btn.textContent = res?.ok ? `اتفتح اختبار ${res.symbol || ""} ✓` : (res?.error || "فشل الاختبار");
  } catch (e) {
    btn.textContent = "فشل الاختبار";
  }
  setTimeout(() => (btn.textContent = "اختبار محلي بسهم من قائمة المراقبة"), 2500);
};

async function refresh() {
  try {
    const status = await chrome.runtime.sendMessage({ type: "getStatus" });
    if (!status) return;
    document.getElementById("mapped").textContent = status.mappedSymbols;
    document.getElementById("buffered").textContent = status.buffered;
    document.getElementById("sent").textContent = status.stats?.sent || 0;
    document.getElementById("dropped").textContent = status.stats?.dropped || 0;
    const lf = status.stats?.lastFlush;
    document.getElementById("lastFlush").textContent = lf ? new Date(lf).toLocaleTimeString() : "—";
    document.getElementById("err").textContent = status.stats?.lastError ? "خطأ: " + status.stats.lastError : "";

    document.getElementById("executedToday").textContent = `${status.executedToday || 0} / ${status.maxPerDay ?? 3}`;
    const lp = status.lastOrderPoll;
    document.getElementById("lastOrderPoll").textContent = lp ? new Date(lp).toLocaleTimeString() : "—";
    document.getElementById("orderErr").textContent = status.lastOrderError ? "أوامر: " + status.lastOrderError : "";
  } catch {}
}

load();
refresh();
setInterval(refresh, 1500);
