/* Runs in the page's MAIN world so it can override window.fetch and
 * intercept Thunder's long-polling + watchlist responses. It posts
 * sanitized events to the content script via window.postMessage. */
(function () {
  const PAGE_SCRIPT_VERSION = "2.1.7-safe-single-dropdown";
  if (window.__thunderTickHooked === PAGE_SCRIPT_VERSION) return;
  window.__thunderTickHooked = PAGE_SCRIPT_VERSION;

  const origFetch = window.fetch.bind(window);

  function send(type, payload) {
    try {
      window.postMessage({ __thunder: true, type, payload }, "*");
    } catch (_) {}
  }

  function isVisible(el) {
    if (!el || el.nodeType !== 1) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.display !== "none" && s.visibility !== "hidden";
  }

  function isDisabled(el) {
    if (!el || el.nodeType !== 1) return true;
    const s = getComputedStyle(el);
    return el.disabled || el.getAttribute("aria-disabled") === "true" || s.pointerEvents === "none";
  }

  function clickTargets(hit) {
    const out = [];
    const add = (node) => {
      if (node && node.nodeType === 1 && !out.includes(node) && isVisible(node) && !isDisabled(node)) out.push(node);
    };
    add(hit);
    add(hit?.closest?.("button, [role='button'], a, input, label, [tabindex], [onclick]"));
    let cur = hit?.parentElement;
    for (let i = 0; cur && i < 7; i++, cur = cur.parentElement) {
      const s = getComputedStyle(cur);
      const r = cur.getBoundingClientRect();
      if (cur.matches?.("button, [role='button'], a, input, label, [tabindex], [onclick]") || s.cursor === "pointer" || (r.width >= 52 && r.width <= 440 && r.height >= 28 && r.height <= 110 && s.backgroundColor !== "rgba(0, 0, 0, 0)")) add(cur);
    }
    return out;
  }

  function makeReactLikeEvent(target, x, y) {
    return {
      bubbles: true,
      cancelable: true,
      composed: true,
      defaultPrevented: false,
      isTrusted: true,
      target,
      currentTarget: target,
      nativeEvent: { detail: 1, isTrusted: true, clientX: x, clientY: y, button: 0, buttons: 0 },
      clientX: x,
      clientY: y,
      button: 0,
      buttons: 0,
      detail: 1,
      preventDefault() { this.defaultPrevented = true; },
      stopPropagation() {},
      persist() {},
      isDefaultPrevented() { return this.defaultPrevented; },
      isPropagationStopped() { return false; },
    };
  }

  function invokeReactClick(target, x, y) {
    let ok = false;
    let cur = target;
    const called = new Set();
    for (let depth = 0; cur && depth < 8; depth++, cur = cur.parentElement) {
      const keys = Object.keys(cur);
      const propsKey = keys.find((k) => k.startsWith("__reactProps$") || k.startsWith("__reactEventHandlers$"));
      const fiberKey = keys.find((k) => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$"));
      const handlers = [];
      const props = propsKey ? cur[propsKey] : null;
      if (typeof props?.onClick === "function") handlers.push(props.onClick);
      let fiber = fiberKey ? cur[fiberKey] : null;
      for (let i = 0; fiber && i < 8; i++, fiber = fiber.return) {
        if (typeof fiber.memoizedProps?.onClick === "function") handlers.push(fiber.memoizedProps.onClick);
      }
      for (const handler of handlers) {
        if (called.has(handler)) continue;
        called.add(handler);
        try {
          handler(makeReactLikeEvent(cur, x, y));
          ok = true;
        } catch (_) {}
      }
    }
    return ok;
  }

  function invokeReactHandlers(target, handlerNames, eventLike) {
    let ok = false;
    let cur = target;
    const called = new Set();
    for (let depth = 0; cur && depth < 8; depth++, cur = cur.parentElement) {
      const keys = Object.keys(cur);
      const propsKey = keys.find((k) => k.startsWith("__reactProps$") || k.startsWith("__reactEventHandlers$"));
      const fiberKey = keys.find((k) => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$"));
      const props = propsKey ? cur[propsKey] : null;
      const handlers = [];
      for (const name of handlerNames) if (typeof props?.[name] === "function") handlers.push(props[name]);
      let fiber = fiberKey ? cur[fiberKey] : null;
      for (let i = 0; fiber && i < 8; i++, fiber = fiber.return) {
        for (const name of handlerNames) if (typeof fiber.memoizedProps?.[name] === "function") handlers.push(fiber.memoizedProps[name]);
      }
      for (const handler of handlers) {
        if (called.has(handler)) continue;
        called.add(handler);
        try { handler({ ...eventLike, currentTarget: cur }); ok = true; } catch (_) {}
      }
    }
    return ok;
  }

  function dispatchClick(target, x, y) {
    try { target.focus?.({ preventScroll: true }); } catch (_) {}
    const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: 1, detail: 1 };
    try {
      if (typeof PointerEvent !== "undefined") {
        target.dispatchEvent(new PointerEvent("pointerover", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true }));
        target.dispatchEvent(new PointerEvent("pointerenter", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true, bubbles: false }));
        target.dispatchEvent(new PointerEvent("pointermove", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true }));
        target.dispatchEvent(new PointerEvent("pointerdown", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true }));
        target.dispatchEvent(new PointerEvent("pointerup", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: 0 }));
      }
      target.dispatchEvent(new MouseEvent("mouseover", base));
      target.dispatchEvent(new MouseEvent("mouseenter", { ...base, bubbles: false }));
      target.dispatchEvent(new MouseEvent("mousemove", base));
      target.dispatchEvent(new MouseEvent("mousedown", base));
      target.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("click", { ...base, buttons: 0 }));
      if (typeof target.click === "function") target.click();
      return true;
    } catch (_) {
      return false;
    }
  }

  function dispatchOneClickAt(x, y, preferredTarget) {
    const hit = document.elementFromPoint(x, y);
    const target = preferredTarget && isVisible(preferredTarget) && !isDisabled(preferredTarget) ? preferredTarget : hit;
    if (!target || !isVisible(target) || isDisabled(target)) return false;
    try { target.scrollIntoView?.({ block: "nearest", inline: "nearest", behavior: "instant" }); } catch (_) {}
    try { target.focus?.({ preventScroll: true }); } catch (_) {}
    const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: 1, detail: 1 };
    try {
      if (typeof PointerEvent !== "undefined") {
        target.dispatchEvent(new PointerEvent("pointermove", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true }));
        target.dispatchEvent(new PointerEvent("pointerdown", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true }));
        target.dispatchEvent(new PointerEvent("pointerup", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: 0 }));
      }
      target.dispatchEvent(new MouseEvent("mousedown", base));
      target.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("click", { ...base, buttons: 0 }));
      return true;
    } catch (_) {
      return false;
    }
  }

  function normalizeArabicText(text) {
    return String(text || "")
      .replace(/[\u064B-\u065F\u0670]/g, "")
      .replace(/[إأآا]/g, "ا")
      .replace(/ى/g, "ي")
      .replace(/ة/g, "ه")
      .replace(/\s+/g, " ")
      .trim();
  }

  function cleanText(el) {
    return ((el?.textContent || "") + " " + (el?.value || "") + " " + (el?.getAttribute?.("aria-label") || "") + " " + (el?.getAttribute?.("title") || ""))
      .replace(/\s+/g, " ")
      .trim();
  }

  function rectsOverlap(a, b) {
    if (!a || !b) return false;
    return a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
  }

  function scoreVisibleTextOption(el, labels, avoidRect) {
    if (!el || !isVisible(el) || isDisabled(el)) return Infinity;
    const r = el.getBoundingClientRect();
    if (r.width < 24 || r.height < 12 || r.width > Math.min(820, window.innerWidth - 12) || r.height > 180) return Infinity;
    if (avoidRect && rectsOverlap(r, avoidRect)) return Infinity;
    const s = getComputedStyle(el);
    if (Number(s.opacity || "1") < 0.08 || s.pointerEvents === "none") return Infinity;
    const text = cleanText(el);
    if (!text || text.length > 180) return Infinity;
    const normalized = normalizeArabicText(text).toLowerCase();
    const wanted = labels.some((label) => normalized.includes(normalizeArabicText(label).toLowerCase()));
    if (!wanted || /سعر محدد|limit|advanced|الطلبات المتقدمه/i.test(normalized)) return Infinity;
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    const hit = document.elementFromPoint(cx, cy);
    if (!hit || !(el === hit || el.contains(hit) || hit.contains(el))) return Infinity;
    const semantic = el.matches?.("[role='option'], [role='menuitem'], [role='menuitemradio'], li, [data-value]") ? 0 : 22;
    const exact = labels.some((label) => normalized === normalizeArabicText(label).toLowerCase()) ? 0 : 18;
    const near = avoidRect ? Math.max(0, r.top - avoidRect.bottom) / 4 + Math.abs(cx - (avoidRect.left + avoidRect.width / 2)) / 10 : 40;
    return semantic + exact + near + Math.max(0, r.height - 54) + Math.max(0, r.width - 280) / 12;
  }

  function selectVisibleText(labels, avoidRect) {
    const selectors = "[role='option'], [role='menuitem'], [role='menuitemradio'], [role='listbox'] *, [data-radix-popper-content-wrapper] *, li[tabindex], li[role], [data-value], li, button, [role='button'], div, span, p";
    const seen = new Set();
    const best = Array.from(document.querySelectorAll(selectors))
      .flatMap((raw) => [raw.closest?.("[role='option'], [role='menuitem'], [role='menuitemradio'], li[tabindex], li[role], [data-value], li, button") || raw, raw])
      .filter((el) => el && !seen.has(el) && seen.add(el))
      .map((el) => ({ el, score: scoreVisibleTextOption(el, labels, avoidRect) }))
      .filter((item) => item.score < Infinity)
      .sort((a, b) => a.score - b.score)[0]?.el;
    if (!best) return false;
    const r = best.getBoundingClientRect();
    const x = r.left + r.width / 2;
    const y = r.top + r.height / 2;
    const reactPointer = invokeReactHandlers(best, ["onPointerMove", "onPointerDown", "onPointerUp", "onMouseDown", "onMouseUp", "onClick"], makeReactLikeEvent(best, x, y));
    const pointed = dispatchOneClickAt(x, y, best);
    try { best.focus?.({ preventScroll: true }); } catch (_) {}
    for (const key of ["Enter", " "]) {
      try {
        const code = key === " " ? "Space" : "Enter";
        const keyEvent = { bubbles: true, cancelable: true, composed: true, key, code, target: best, currentTarget: best, nativeEvent: { key, code }, preventDefault() {}, stopPropagation() {} };
        invokeReactHandlers(best, ["onKeyDown", "onKeyUp"], keyEvent);
        best.dispatchEvent(new KeyboardEvent("keydown", { key, code, bubbles: true, cancelable: true, composed: true }));
        best.dispatchEvent(new KeyboardEvent("keyup", { key, code, bubbles: true, cancelable: true, composed: true }));
        return true;
      } catch (_) {}
    }
    return reactPointer || pointed || invokeReactClick(best, x, y);
  }

  function typeIntoAt(x, y, text) {
    let el = document.elementFromPoint(x, y);
    el = el?.closest?.("input:not([type='hidden']), textarea, [contenteditable='true']") || document.activeElement;
    if (!el || !isVisible(el) || isDisabled(el)) return false;
    try { el.focus(); } catch (_) {}
    if (el.isContentEditable) {
      el.textContent = String(text);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, inputType: "insertText", data: String(text) }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
    const proto = Object.getPrototypeOf(el);
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(el, String(text)); else el.value = String(text);
    el.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, inputType: "insertText", data: String(text) }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  window.addEventListener("message", (event) => {
    const msg = event.data;
    if (event.source !== window || !msg || msg.__thunderMainCommand !== true) return;
    let ok = false;
    try {
      if (msg.action === "clickAt") {
        const x = Number(msg.payload?.x);
        const y = Number(msg.payload?.y);
        const hit = document.elementFromPoint(x, y);
        const targets = clickTargets(hit);
        for (const target of targets) ok = invokeReactClick(target, x, y) || ok;
        for (const target of targets) ok = dispatchClick(target, x, y) || ok;
      } else if (msg.action === "preciseClickAt") {
        ok = dispatchOneClickAt(Number(msg.payload?.x), Number(msg.payload?.y));
      } else if (msg.action === "selectVisibleText") {
        ok = selectVisibleText(Array.isArray(msg.payload?.labels) ? msg.payload.labels : [], msg.payload?.avoidRect || null);
      } else if (msg.action === "typeAt") {
        ok = typeIntoAt(Number(msg.payload?.x), Number(msg.payload?.y), msg.payload?.text ?? "");
      }
    } catch (_) {}
    window.postMessage({ __thunderMainResult: true, id: msg.id, ok }, "*");
  });

  // JSONP-ish payload: pRTLPCB(serial, [{t:"d", d:{b:{p:"marketFeed/<uuid>/price", d:<value>}}}])
  function parseLongPoll(text) {
    const out = [];
    if (!text) return out;
    const ts = new Date().toISOString();
    // Use regex to find all price entries — robust to wrapper changes.
    const re = /"p"\s*:\s*"marketFeed\/([0-9a-f-]{36})\/price"\s*,\s*"d"\s*:\s*([0-9]+(?:\.[0-9]+)?)/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      const uuid = m[1];
      const price = parseFloat(m[2]);
      if (uuid && price > 0 && price < 100000) {
        out.push({ uuid, price, ts });
      }
    }
    return out;
  }

  function parseWatchlist(json) {
    if (!json) return [];
    // Walk any JSON structure and collect every object that looks like an asset:
    // has a uuid-like id AND a symbol-like ticker string.
    const out = [];
    const seen = new Set();
    const uuidRe = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    function visit(node) {
      if (!node) return;
      if (Array.isArray(node)) { for (const x of node) visit(x); return; }
      if (typeof node !== "object") return;
      const uuid = node.id || node.uuid || node.asset_id || node.assetId;
      const symbol = node.symbol || node.ticker || node.code;
      if (uuid && symbol && typeof uuid === "string" && uuidRe.test(uuid) && !seen.has(uuid)) {
        seen.add(uuid);
        out.push({
          uuid,
          symbol: String(symbol).toUpperCase(),
          name: node.name ?? node.name_ar ?? node.name_en ?? null,
          day_tradable: !!(node?.feed?.day_tradable ?? node?.day_tradable),
        });
      }
      for (const k of Object.keys(node)) {
        const v = node[k];
        if (v && typeof v === "object") visit(v);
      }
    }
    try { visit(json); } catch {}
    return out;
  }

  window.fetch = async function patchedFetch(input, init) {
    const resp = await origFetch(input, init);
    try {
      const url = typeof input === "string" ? input : input?.url || "";
      if (!url) return resp;

      // Long-polling endpoint: contains "/lp?" with serial id
      if (url.includes("/lp?") || /[?&](id|ser)=/.test(url)) {
        const clone = resp.clone();
        clone.text().then((txt) => {
          const ticks = parseLongPoll(txt);
          if (ticks.length) send("ticks", ticks);
        }).catch(() => {});
      }
      // Any JSON response: scan for {uuid, symbol} pairs.
      else {
        const clone = resp.clone();
        const ct = (resp.headers.get("content-type") || "").toLowerCase();
        if (ct.includes("json")) {
          clone.json().then((json) => {
            const mapping = parseWatchlist(json);
            if (mapping.length) send("watchlist", mapping);
          }).catch(() => {});
        }
      }
    } catch (_) {}
    return resp;
  };

  // Also hook XMLHttpRequest — Thunder may use XHR for watchlist/assets.
  const OrigXHR = window.XMLHttpRequest;
  function HookedXHR() {
    const xhr = new OrigXHR();
    xhr.addEventListener("load", function () {
      try {
        const url = xhr.responseURL || "";
        const ct = (xhr.getResponseHeader && xhr.getResponseHeader("content-type") || "").toLowerCase();
        const txt = xhr.responseText;
        if (!txt) return;
        if (url.includes("/lp?") || /[?&](id|ser)=/.test(url)) {
          const ticks = parseLongPoll(txt);
          if (ticks.length) send("ticks", ticks);
        } else if (ct.includes("json") || txt.trim().startsWith("{") || txt.trim().startsWith("[")) {
          try {
            const json = JSON.parse(txt);
            const mapping = parseWatchlist(json);
            if (mapping.length) send("watchlist", mapping);
          } catch {}
        }
      } catch {}
    });
    return xhr;
  }
  HookedXHR.prototype = OrigXHR.prototype;
  try { window.XMLHttpRequest = HookedXHR; } catch {}
})();