/* Background service worker.
 * - Phase 1: ticks ingest (read-only)  → handleTicks/handleWatchlist/flush
 * - Phase 2: Semi-Auto orders         → pollOrders + dispatchOrder
 * - Phase 3: Remote Config (v2.2.0)   → config.js (kill_switch + live updates)
 *
 * Semi-Auto rules:
 *   - Auto-Execute is OFF by default. User must enable in popup.
 *   - Max N orders per day (user-configurable, default 3).
 *   - Per-order timeout: skip only after expires_at (server-controlled).
 *   - We DO NOT click the final "مراجعة الطلب" / confirm button. We stop
 *     at the prepared form so the user reviews and submits.
 */

importScripts("config.js");

// === v4 Unified: CDP module ===
// Load synchronously so its message listeners (cdp.*) are registered the moment
// the service worker wakes — even before the user toggles tickCDP on.
// Registering listeners does NOT trigger Chrome's yellow "is being debugged"
// bar — only chrome.debugger.attach() does, and that runs only when the user
// clicks "اتصل بتاب ثاندر" in the popup.
try { importScripts("cdp-module.js"); }
catch (e) { console.warn("[v4] cdp-module load failed:", e); }

// First-install: seed v4_features with safe defaults.
chrome.runtime.onInstalled?.addListener?.(async () => {
  const { v4_features } = await chrome.storage.local.get(["v4_features"]);
  if (!v4_features) {
    await chrome.storage.local.set({
      v4_features: { tickHooks: true, tickCDP: false, orders: true, positions: true, sellT0: true, overlay: true, driftGuard: true }
    });
  }
  // Migrate legacy `token` → `v4_token` so popup field stays populated.
  const { token, v4_token } = await chrome.storage.local.get(["token", "v4_token"]);
  if (!v4_token && token) await chrome.storage.local.set({ v4_token: token });
});

const FLUSH_MS = 2000;
const ORDER_POLL_MS = 1000;
const POSITIONS_POLL_MS = 2000;
const AUTO_INJECT_MS = 2000;
const BACKEND_LIVE_POLL_MS = 60000;
const MAX_BUFFER = 500;
const CONTENT_SCRIPT_VERSION = "v4.1.69";
// v4.1.63 — Math-only viability guard (لا يلمس قراءة ثاندر ولا حالة التاب).
// أُزيلت الفحوصات المعتمدة على السعر اللحظي (stale price, slippage, day high)
// عشان منمنعش صفقة بسبب تأخر تحديث من قائمة المراقبة.  الفحوصات الباقية
// كلها حسابية بحتة (عمولة + سقف الموجة السابقة + هدف الاستراتيجية).
const MIN_SCALP_CASH_EGP = 1000;
const MIN_SCALP_NOTIONAL_EGP = 900;
const TARGET_NET_PROFIT_PCT = 0.005;
const MAX_REQUIRED_MOVE_PCT = 0.012;
// Default "source of truth" tab for live prices/watchlist mapping. The user
// configures this in the popup; only messages from a tab whose URL starts
// with this prefix are accepted as price/watchlist input. This prevents a
// newly opened order tab (e.g. /ar/assets/<uuid>) from silently becoming
// the data source and breaking the original watchlist long-poll.
const DEFAULT_PRICE_SOURCE_URL = "https://web.thndr.app/ar/watchlist";
const EXECUTE_ORDER_MESSAGE = "executeOrderV3";
const ACTIVE_TRADE_LEDGER_KEY = "v4_active_scalp_trades";
const SIGNAL_LEDGER_KEY = "v4_scalp_signals";
const DEFAULT_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/thunder-ticks";
const BACKEND_LIVE_POLL_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/live-tick-poll";
const ORDERS_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/thunder-orders";
const POSITIONS_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/thunder-positions";
const TRADES_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/extension-trades";
const ORDERBOOK_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/orderbook-snapshot";
const WATCHLIST_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/thunder-watchlist";
const TIMELINE_ENDPOINT = "https://meky-stock.lovable.app/api/public/hooks/scalp-timeline";
const TRADE_JOURNAL_KEY = "v4_trade_journal";  // { "YYYY-MM-DD": [tradeRow,...] }
const CAPTURE_KEY = "v4_capture_session";       // { active, startedAt, expiresAt, symbol, events: [] }
const CAPTURE_MAX_EVENTS = 800;
const CAPTURE_DEFAULT_TTL_MS = 20 * 60 * 1000;

// ---- Redaction for captured Thunder responses ----
const HEADER_DROP = /^(authorization|cookie|set-cookie|x-firebase-.*|x-thndr-token|x-api-key|x-auth.*)$/i;
const KEY_REDACT = /(token|secret|password|jwt|api[_-]?key|refresh[_-]?token|id[_-]?token|access[_-]?token|cookie|auth|bearer|session|csrf|xsrf|signature|sig|otp|pin)/i;
const KEY_PARTIAL = /(user_id|account_id|customer_id|email|phone|mobile|national_id|nin|iban)/i;
// Catch raw JWTs that slip through under innocent keys (3 base64url parts).
const JWT_RE = /\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b/g;
function redactJwtsInString(s) {
  if (typeof s !== "string") return s;
  return s.replace(JWT_RE, "***JWT_REDACTED***");
}
function redactUrl(u) {
  if (typeof u !== "string" || !u) return u || "";
  try {
    const url = new URL(u);
    for (const k of Array.from(url.searchParams.keys())) {
      if (KEY_REDACT.test(k)) url.searchParams.set(k, "***REDACTED***");
      else if (KEY_PARTIAL.test(k)) url.searchParams.set(k, redactValue(url.searchParams.get(k) || ""));
      else url.searchParams.set(k, redactJwtsInString(url.searchParams.get(k) || ""));
    }
    return url.toString();
  } catch { return redactJwtsInString(u); }
}

function redactHeaders(h) {
  const out = {};
  if (!h || typeof h !== "object") return out;
  for (const k of Object.keys(h)) {
    if (HEADER_DROP.test(k)) { out[k] = "***REDACTED***"; continue; }
    out[k] = h[k];
  }
  return out;
}
function redactValue(v) {
  if (typeof v !== "string") return "***REDACTED***";
  if (v.length <= 8) return "***";
  return v.slice(0, 4) + "***" + v.slice(-2);
}
function redactObj(node, depth = 0) {
  if (depth > 8 || node == null) return node;
  if (Array.isArray(node)) return node.map((x) => redactObj(x, depth + 1));
  if (typeof node === "string") return redactJwtsInString(node);
  if (typeof node !== "object") return node;
  const out = {};
  for (const k of Object.keys(node)) {
    if (KEY_REDACT.test(k)) { out[k] = "***REDACTED***"; continue; }
    if (KEY_PARTIAL.test(k)) { out[k] = redactValue(node[k]); continue; }
    out[k] = redactObj(node[k], depth + 1);
  }
  return out;
}
function redactBody(text) {
  if (typeof text !== "string" || !text) return text || null;
  // Try JSON; if not JSON return as-is (truncated upstream).
  try {
    const parsed = JSON.parse(text);
    return JSON.stringify(redactObj(parsed));
  } catch {
    // Non-JSON (form-urlencoded, plain text): still scrub JWTs and obvious key=value secrets.
    let s = redactJwtsInString(text);
    s = s.replace(/(token|secret|password|jwt|api[_-]?key|refresh[_-]?token|id[_-]?token|access[_-]?token|bearer|session|csrf|xsrf|signature|otp|pin)=([^&\s]+)/gi, "$1=***REDACTED***");
    return s;
  }
}

async function getCaptureSession() {
  const s = await chrome.storage.local.get([CAPTURE_KEY]);
  return s[CAPTURE_KEY] || null;
}
async function setCaptureSession(sess) {
  await chrome.storage.local.set({ [CAPTURE_KEY]: sess });
}
async function recordCaptureEvent(raw) {
  const sess = await getCaptureSession();
  if (!sess || !sess.active) return;
  if (Date.now() > sess.expiresAt) { sess.active = false; await setCaptureSession(sess); return; }
  const ev = {
    ts_ms: raw.ts_ms || Date.now(),
    source: raw.source || "fetch",
    method: raw.method || "GET",
    url: redactUrl(raw.url || ""),
    status: raw.status || 0,
    req_body: redactBody(raw.req_body),
    resp_headers: redactHeaders(raw.resp_headers || {}),
    resp_body: redactBody(raw.resp_body),
    page_url: redactUrl(raw.page_url || ""),
  };
  sess.events = sess.events || [];
  sess.events.push(ev);
  if (sess.events.length > CAPTURE_MAX_EVENTS) sess.events = sess.events.slice(-CAPTURE_MAX_EVENTS);
  sess.lastEventAt = ev.ts_ms;
  await setCaptureSession(sess);
}
async function startCaptureSession(opts) {
  const sess = {
    active: true,
    startedAt: Date.now(),
    expiresAt: Date.now() + (opts?.ttlMs || CAPTURE_DEFAULT_TTL_MS),
    symbol: opts?.symbol || null,
    uuid: opts?.uuid || null,
    events: [],
    lastEventAt: null,
  };
  await setCaptureSession(sess);
  // Flip the page-script flag in every Thunder tab.
  const tabs = await chrome.tabs.query({ url: ["https://web.thndr.app/*", "https://*.thndr.app/*"] });
  for (const t of tabs) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: t.id, allFrames: true },
        world: "MAIN",
        func: () => { try { window.__thunderCapture = true; } catch {} },
      });
    } catch {}
  }
  return sess;
}
async function stopCaptureSession() {
  const sess = await getCaptureSession();
  if (sess) { sess.active = false; sess.stoppedAt = Date.now(); await setCaptureSession(sess); }
  const tabs = await chrome.tabs.query({ url: ["https://web.thndr.app/*", "https://*.thndr.app/*"] });
  for (const t of tabs) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: t.id, allFrames: true },
        world: "MAIN",
        func: () => { try { window.__thunderCapture = false; } catch {} },
      });
    } catch {}
  }
  return sess;
}
async function clearCaptureSession() { await chrome.storage.local.remove([CAPTURE_KEY]); }

// Re-arm capture flag on every Thunder tab load while session is active.
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== "complete") return;
  if (!/^https:\/\/([^/]+\.)?thndr\.app\//.test(tab?.url || "")) return;
  const sess = await getCaptureSession();
  if (!sess || !sess.active) return;
  if (Date.now() > sess.expiresAt) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      world: "MAIN",
      func: () => { try { window.__thunderCapture = true; } catch {} },
    });
  } catch {}
});

// Open cheapest stock + start capture. Symbol must already exist in mapping
// (i.e. user visited Thunder watchlist before). Falls back to opening
// Thunder home so user can add it manually.
async function startCaptureForSymbol(symbol) {
  const sym = String(symbol || "").trim().toUpperCase();
  const entry = Object.entries(mapping).find(([, m]) => normalizeSymbol(m?.symbol) === sym);
  const uuid = entry ? entry[0] : null;
  const url = uuid ? `https://web.thndr.app/ar/assets/${uuid}` : "https://web.thndr.app/ar";
  const tab = await chrome.tabs.create({ url, active: true });
  if (tab?.windowId != null) { try { await chrome.windows.update(tab.windowId, { focused: true }); } catch {} }
  // Wait briefly for the page to register before enabling the flag.
  await new Promise((r) => setTimeout(r, 1500));
  await startCaptureSession({ symbol: sym, uuid });
  return { ok: true, symbol: sym, uuid, url, tabId: tab?.id, hasMapping: !!uuid };
}

// Thunder Egypt commission (verified): 3 EGP fixed + 0.03% of value per side.
function calcFee(value) {
  const v = Number(value) || 0;
  if (v <= 0) return 0;
  return Number((3 + 0.0003 * v).toFixed(4));
}
function cairoDateStr(d = new Date()) {
  return new Date(d.toLocaleString("en-US", { timeZone: "Africa/Cairo" }))
    .toISOString().slice(0, 10);
}

let buffer = [];
let mapping = {};                          // uuid -> { symbol, name, day_tradable }
let stats = { sent: 0, dropped: 0, lastFlush: 0, lastError: null, jsonpCalls: 0, jsonpWithFeed: 0, wsMessages: 0, wsWithFeed: 0, domTicks: 0, backendPolls: 0, backendPollRows: 0, lastBackendPoll: 0, injectedTabs: 0, lastInject: 0, injectError: null, lastTick: null, crossTabDropped: 0 };
let priceSourceUrl = DEFAULT_PRICE_SOURCE_URL;
let dispatchedToday = {};                  // orderId -> true (in-memory dedupe)
let inFlightOrders = {};                   // orderId -> true while preparing it
let failedOrders = {};                     // orderId -> true after a terminal local failure; prevents UI click loops
let lastOrderPoll = 0;
let lastOrderError = null;
let openPositions = {};                    // symbol(UPPER) -> { id, qty, tp, sl, entry }
let triggeredSells = {};                   // position_id -> ts (dedupe local sells)
let lastPositionsPoll = 0;
let lastPositionsError = null;
let detectedPositionPosts = {};            // symbol -> last post ts (dedupe Thunder portfolio sniffing)
let registeredBuyFills = {};               // symbol|qty|price -> ts (dedupe register_buy_fill posts)
let keepAlivePort = null;
let lastKeepAlivePing = 0;
let latestPriceBySymbol = {};              // symbol -> { price, ts }
let dayStatsDate = cairoDateStr();
let dayStatsBySymbol = {};                 // symbol -> { high, low, latest, updatedAt }

chrome.storage.local.get(["mapping", "stats"]).then((s) => {
  mapping = s.mapping || {};
  stats = { ...stats, ...(s.stats || {}) };
});

// Load + watch the configured price-source URL prefix.
chrome.storage.local.get(["priceSourceUrl"]).then((s) => {
  if (typeof s.priceSourceUrl === "string" && s.priceSourceUrl.trim()) {
    priceSourceUrl = s.priceSourceUrl.trim();
  }
});
chrome.storage.onChanged?.addListener?.((changes, area) => {
  if (area !== "local") return;
  if (changes.priceSourceUrl) {
    const v = changes.priceSourceUrl.newValue;
    priceSourceUrl = (typeof v === "string" && v.trim()) ? v.trim() : DEFAULT_PRICE_SOURCE_URL;
  }
});

/**
 * Returns true if the sender tab URL is the user's configured price source.
 * Empty/unknown URL → reject (e.g. message came from a frame we can't trust).
 * If priceSourceUrl is empty (user cleared it), we fall back to accepting any
 * Thunder tab to preserve old behaviour.
 */
function isPriceSourceSender(sender) {
  const url = sender?.tab?.url || sender?.url || "";
  if (!priceSourceUrl) return /^https:\/\/([^/]+\.)?thndr\.app\//.test(url);
  return typeof url === "string" && url.startsWith(priceSourceUrl);
}

// Phase 3: تشغيل Remote Config + Realtime عند بدء الـ service worker
initRemoteConfig().catch(() => {});
chrome.runtime.onStartup?.addListener?.(() => { initRemoteConfig().catch(() => {}); });
chrome.runtime.onInstalled?.addListener?.(() => { initRemoteConfig().catch(() => {}); });
chrome.runtime.onStartup?.addListener?.(() => { autoInjectThunderTabs().catch(() => {}); });
chrome.runtime.onInstalled?.addListener?.(() => { autoInjectThunderTabs().catch(() => {}); });
chrome.alarms?.create?.("thunderSemiAutoHeartbeat", { periodInMinutes: 0.5 });
chrome.alarms?.onAlarm?.addListener?.((alarm) => {
  if (alarm.name !== "thunderSemiAutoHeartbeat") return;
  flush().catch(() => {});
  pollOrders().catch(() => {});
  pollPositions().catch(() => {});
  autoInjectThunderTabs().catch(() => {});
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg) return;
  lastKeepAlivePing = Date.now();
  // Hard filter: price/watchlist signals must come from the configured
  // watchlist tab only. Order tabs, mock pages, asset pages, etc. are ignored
  // for price ingestion so they cannot hijack the data source.
  const isPriceMsg = msg.type === "ticks" || msg.type === "watchlist" || msg.type === "jsonp" || msg.type === "ws";
  if (isPriceMsg && !isPriceSourceSender(_sender)) {
    stats.crossTabDropped = (stats.crossTabDropped || 0) + 1;
    chrome.storage.local.set({ stats });
    return;
  }
  if (msg.type === "ticks") {
    handleTicks(msg.payload);
  } else if (msg.type === "jsonp") {
    stats.jsonpCalls = (stats.jsonpCalls || 0) + 1;
    if (msg.payload?.hasFeed) stats.jsonpWithFeed = (stats.jsonpWithFeed || 0) + 1;
    chrome.storage.local.set({ stats });
  } else if (msg.type === "ws") {
    stats.wsMessages = (stats.wsMessages || 0) + 1;
    if (msg.payload?.hasFeed) stats.wsWithFeed = (stats.wsWithFeed || 0) + 1;
    chrome.storage.local.set({ stats });
  } else if (msg.type === "watchlist") {
    handleWatchlist(msg.payload);
  } else if (msg.type === "orderStatus") {
    // Content script reports back: { id, status, error_message? }
    reportOrderStatus(msg.payload).catch(() => {});
  } else if (msg.type === "buyFill") {
    // page-script detected confirmed buy fills in a Thunder JSON response.
    // We forward each one to the server so it can create a `positions` row
    // (TP/SL pulled from the matching paper_trades on the server side).
    registerBuyFills(msg.payload).catch(() => {});
    // Timeline: real Thunder-confirmed buy fill.
    try {
      const fills = Array.isArray(msg.payload) ? msg.payload : [];
      const now = Date.now();
      for (const f of fills) {
        if (!f?.symbol) continue;
        recordTimelineEvent({
          signal_id: f.order_id ? String(f.order_id) : null,
          symbol: normalizeSymbol(f.symbol),
          uuid: f.uuid || null,
          event: "buy_confirmed",
          at_ms: now,
          meta: { qty: Number(f.qty) || null, price: Number(f.price) || null },
        }).catch(() => {});
      }
    } catch {}
  } else if (msg.type === "sellFill") {
    registerSellFills(msg.payload).catch(() => {});
    try {
      const fills = Array.isArray(msg.payload) ? msg.payload : [];
      const now = Date.now();
      for (const f of fills) {
        if (!f?.symbol) continue;
        recordTimelineEvent({
          signal_id: f.order_id ? String(f.order_id) : null,
          symbol: normalizeSymbol(f.symbol),
          uuid: f.uuid || null,
          event: "sell_confirmed",
          at_ms: now,
          meta: { qty: Number(f.qty) || null, price: Number(f.price) || null },
        }).catch(() => {});
      }
    } catch {}
  } else if (msg.type === "l2Snapshot") {
    recordOrderbookSnapshot(msg.payload || {}).catch(() => {});
  } else if (msg.type === "timelineEvent") {
    recordTimelineEvent(msg.payload || {}).catch(() => {});
  } else if (msg.type === "captureEvent") {
    recordCaptureEvent(msg.payload || {}).catch(() => {});
  } else if (msg.type === "capture.start") {
    startCaptureForSymbol(msg.payload?.symbol || "COPR")
      .then(sendResponse)
      .catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  } else if (msg.type === "capture.stop") {
    stopCaptureSession().then((s) => sendResponse({ ok: true, session: s })).catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  } else if (msg.type === "capture.status") {
    getCaptureSession().then((s) => sendResponse({ ok: true, session: s })).catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  } else if (msg.type === "capture.clear") {
    clearCaptureSession().then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  } else if (msg.type === "capture.armForSignal") {
    // In-place arm: do NOT open a tab. Used by content.js when a Scalp signal
    // triggers a buy. Reuses any existing active session (extends TTL) so a
    // single session captures buy + fill + sell across the whole flow.
    (async () => {
      try {
        const existing = await getCaptureSession();
        const sym = String(msg.payload?.symbol || "").toUpperCase() || null;
        const uuid = msg.payload?.uuid || null;
        const meta = msg.payload?.meta || null;
        if (existing && existing.active && Date.now() < (existing.expiresAt || 0)) {
          existing.expiresAt = Date.now() + (45 * 60_000);
          existing.signalMeta = meta || existing.signalMeta || null;
          if (!existing.symbol && sym) existing.symbol = sym;
          await setCaptureSession(existing);
          sendResponse({ ok: true, reused: true, session: existing });
        } else {
          const sess = await startCaptureSession({ symbol: sym, uuid, ttlMs: 45 * 60_000 });
          sess.signalMeta = meta || null;
          await setCaptureSession(sess);
          sendResponse({ ok: true, reused: false, session: sess });
        }
      } catch (e) { sendResponse({ ok: false, error: String(e?.message || e) }); }
    })();
    return true;
  } else if (msg.type === "getStatus") {
    autoInjectThunderTabs().catch(() => {});
    chrome.storage.local.get(["autoExec", "maxPerDay", "egpPerTrade"]).then((cfg) => {
      sendResponse({
        mappedSymbols: Object.keys(mapping).length,
        buffered: buffer.length,
        stats,
        autoExec: cfg.autoExec === true,
        maxPerDay: cfg.maxPerDay ?? 3,
        egpPerTrade: Math.max(MIN_SCALP_CASH_EGP, Number(cfg.egpPerTrade) || MIN_SCALP_CASH_EGP),
        executedToday: Object.keys(dispatchedToday).length,
        lastOrderPoll,
        lastOrderError,
        remoteConfig: getRemoteConfigStatus(),
      });
    });
    return true;
  } else if (msg.type === "clearMapping") {
    mapping = {};
    chrome.storage.local.set({ mapping });
    sendResponse({ ok: true });
    return true;
  } else if (msg.type === "runLocalOrderTest") {
    runLocalOrderTest().then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  } else if (msg.type === "runLocalSellTest") {
    runLocalSellTest().then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  } else if (msg.type === "runOpenTabTest") {
    runOpenTabTest().then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  } else if (msg.type === "getSymbolForUuid") {
    const uuid = normalizeUuid(msg.payload?.uuid);
    const sym = uuid ? mapping[uuid]?.symbol || null : null;
    sendResponse({ ok: true, symbol: sym ? normalizeSymbol(sym) : null });
    return true;
  } else if (msg.type === "getTradeJournal") {
    getTradeJournal(msg.payload?.date).then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }
});

chrome.runtime.onConnect?.addListener?.((port) => {
  if (port?.name !== "thunder-v4-keepalive") return;
  keepAlivePort = port;
  lastKeepAlivePing = Date.now();
  port.onMessage?.addListener?.((msg) => {
    if (msg?.type === "keepalive") {
      lastKeepAlivePing = Date.now();
      try { port.postMessage({ ok: true, ts: lastKeepAlivePing }); } catch {}
    }
  });
  port.onDisconnect?.addListener?.(() => {
    if (keepAlivePort === port) keepAlivePort = null;
  });
});

function handleWatchlist(arr) {
  let changed = false;
  for (const item of arr || []) {
    if (!item?.uuid || !item?.symbol) continue;
    const cur = mapping[item.uuid];
    if (!cur || cur.symbol !== item.symbol) {
      mapping[item.uuid] = {
        symbol: item.symbol,
        name: item.name || null,
        day_tradable: !!item.day_tradable,
      };
      changed = true;
    }
  }
  if (changed) chrome.storage.local.set({ mapping });
  // Passive server persistence — one snapshot per uuid per hour is enough
  // (these fields change slowly). Zero new Thunder traffic.
  recordWatchlistSnapshots(arr).catch(() => {});
}

function handleTicks(arr) {
  if (!Array.isArray(arr)) return;
  const enriched = [];
  for (const t of arr) {
    const directSymbol = normalizeSymbol(t.symbol);
    const m = mapping[t.uuid];
    const symbol = directSymbol || normalizeSymbol(m?.symbol);
    if (!symbol) { stats.dropped++; continue; }
    if (t.uuid && directSymbol && (!m || normalizeSymbol(m.symbol) !== directSymbol)) {
      mapping[t.uuid] = { ...(m || {}), symbol: directSymbol };
      chrome.storage.local.set({ mapping }).catch(() => {});
    }
    const row = { symbol, price: t.price, ts: t.ts, uuid: t.uuid, volume: t.volume ?? null };
    buffer.push(row);
    enriched.push(row);
    rememberLocalPrice(symbol, t.price, t.ts);
    if (t.source === "dom") stats.domTicks = (stats.domTicks || 0) + 1;
    stats.lastTick = { symbol, price: Number(t.price) || 0, ts: Date.now() };
    // Local sell-watcher: detect TP/SL hits instantly on the tick stream.
    checkLocalSell(symbol, t.price).catch(() => {});
  }
  if (buffer.length > MAX_BUFFER) buffer = buffer.slice(-MAX_BUFFER);
  if (enriched.length) chrome.storage.local.set({ stats }).catch(() => {});
  if (enriched.length) broadcastToThunderTabs({ type: "ticksUpdate", payload: enriched.slice(-100) });
  if (enriched.length) flush().catch(() => {});
}

function rememberLocalPrice(symbol, rawPrice, rawTs) {
  const sym = normalizeSymbol(symbol);
  const price = Number(rawPrice) || 0;
  if (!sym || price <= 0) return;
  const now = Date.now();
  const tsNum = typeof rawTs === "number" ? rawTs : new Date(rawTs || now).getTime();
  const ts = Number.isFinite(tsNum) ? tsNum : now;
  latestPriceBySymbol[sym] = { price, ts };
  const today = cairoDateStr();
  if (today !== dayStatsDate) {
    dayStatsDate = today;
    dayStatsBySymbol = {};
  }
  const prev = dayStatsBySymbol[sym] || { high: price, low: price, latest: price, updatedAt: ts };
  dayStatsBySymbol[sym] = {
    high: Math.max(Number(prev.high) || price, price),
    low: Math.min(Number(prev.low) || price, price),
    latest: price,
    updatedAt: Math.max(Number(prev.updatedAt) || 0, ts),
  };
}

function calcViabilitySafeSellPrice(buyPrice, qty, netProfitPct = TARGET_NET_PROFIT_PCT) {
  const p = Number(buyPrice) || 0;
  const q = Math.max(1, Math.floor(Number(qty) || 0));
  if (p <= 0 || q <= 0) return 0;
  const buyValue = p * q;
  const buyFee = calcFee(buyValue);
  const desiredNetProfit = buyValue * (Number(netProfitPct) || 0);
  // sellValue - sellFee >= buyValue + buyFee + desiredNetProfit
  // S*q - (3 + 0.0003*S*q) >= buyValue + buyFee + desiredNetProfit
  return (buyValue + buyFee + 3 + desiredNetProfit) / (q * (1 - 0.0003));
}

function numberFromMeta(meta, keys) {
  if (!meta || typeof meta !== "object") return 0;
  for (const key of keys) {
    const n = Number(meta[key]);
    if (Number.isFinite(n) && n > 0) return n;
  }
  return 0;
}

function assessBuyViability(order, { qty, egp, qtyMode }) {
  const side = String(order?.side || "buy").toLowerCase();
  if (side === "sell") return { ok: true, reason: "sell_order" };

  const symbol = normalizeSymbol(order?.symbol);
  const refPrice = Number(order?.ref_price) || 0;
  if (!symbol || refPrice <= 0) return { ok: false, code: "missing_ref_price" };

  const latest = latestPriceBySymbol[symbol];
  const latestPrice = latest && Number(latest.price) > 0 ? Number(latest.price) : 0;
  // v4.1.63: استخدم السعر اللحظي لو موجود، وإلا ارجع لسعر الإشارة بدون منع
  // الصفقة. مفيش إجبار على تحديث حديث عشان منكسرش الشراء بسبب تأخر تاب.
  const entryPrice = latestPrice > 0 ? latestPrice : refPrice;
  const q = Math.max(1, Math.floor(Number(qty) || 0));
  const intendedCash = Math.max(0, Number(egp) || 0);
  const effectiveCash = qtyMode === "fixed" ? q * entryPrice : intendedCash;
  const expectedQty = qtyMode === "fixed" ? q : Math.max(1, Math.floor((effectiveCash || entryPrice) / entryPrice));
  const expectedNotional = expectedQty * entryPrice;

  if (qtyMode !== "fixed" && effectiveCash < MIN_SCALP_CASH_EGP) {
    return {
      ok: false,
      code: "cash_below_minimum",
      detail: `مبلغ الصفقة ${effectiveCash.toFixed(0)}ج أقل من الحد الآمن ${MIN_SCALP_CASH_EGP}ج`,
      entryPrice, refPrice, expectedQty, expectedNotional,
    };
  }
  if (expectedNotional < MIN_SCALP_NOTIONAL_EGP) {
    return {
      ok: false,
      code: "notional_below_minimum",
      detail: `القيمة المتوقعة ${expectedNotional.toFixed(0)}ج صغيرة والعمولة الثابتة هتأكل الربح`,
      entryPrice, refPrice, expectedQty, expectedNotional,
    };
  }

  const safeSell = calcViabilitySafeSellPrice(entryPrice, expectedQty, TARGET_NET_PROFIT_PCT);
  const requiredMovePct = safeSell > 0 ? (safeSell - entryPrice) / entryPrice : 0;
  if (requiredMovePct > MAX_REQUIRED_MOVE_PCT) {
    return {
      ok: false,
      code: "required_move_unrealistic",
      detail: `لازم السهم يطلع ${(requiredMovePct * 100).toFixed(2)}% بعد العمولات عشان يكسب`,
      entryPrice, refPrice, expectedQty, expectedNotional, safeSell, requiredMovePct,
    };
  }

  const meta = order?.metadata || {};
  const recentCeiling = numberFromMeta(meta, ["recent_ceiling_price", "lookback_ref_price", "pre_drop_price"]);
  if (recentCeiling > 0 && safeSell > recentCeiling) {
    return {
      ok: false,
      code: "safe_sell_above_recent_ceiling",
      detail: `سعر البيع الآمن ${safeSell.toFixed(2)} أعلى من سقف آخر حركة ${recentCeiling.toFixed(2)}`,
      entryPrice, refPrice, expectedQty, expectedNotional, safeSell, requiredMovePct, recentCeiling,
    };
  }

  const localDayHigh = Number(dayStatsBySymbol[symbol]?.high) || 0;
  const metaDayHigh = numberFromMeta(meta, ["day_high_so_far", "day_high", "high_so_far"]);
  const dayHigh = Math.max(localDayHigh, metaDayHigh);

  const strategyTp = numberFromMeta(meta, ["tp_price", "target_price", "theoretical_tp"]);
  if (strategyTp > 0 && safeSell > strategyTp) {
    return {
      ok: false,
      code: "safe_sell_above_strategy_target",
      detail: `سعر البيع الآمن ${safeSell.toFixed(2)} أعلى من هدف الاستراتيجية ${strategyTp.toFixed(2)}`,
      entryPrice, refPrice, expectedQty, expectedNotional, safeSell, requiredMovePct, strategyTp,
    };
  }

  return {
    ok: true,
    code: "viable",
    entryPrice, refPrice, expectedQty, expectedNotional, safeSell, requiredMovePct,
    dayHigh: dayHigh || null,
    usedFreshTick: latestPrice > 0,
  };
}

function formatViabilityBlock(v) {
  const parts = [v?.code || "blocked"];
  if (v?.detail) parts.push(v.detail);
  if (Number(v?.entryPrice) > 0) parts.push(`entry=${Number(v.entryPrice).toFixed(3)}`);
  if (Number(v?.refPrice) > 0) parts.push(`ref=${Number(v.refPrice).toFixed(3)}`);
  if (Number(v?.expectedQty) > 0) parts.push(`qty=${Number(v.expectedQty).toFixed(0)}`);
  if (Number(v?.safeSell) > 0) parts.push(`safeSell=${Number(v.safeSell).toFixed(3)}`);
  if (Number(v?.dayHigh) > 0) parts.push(`dayHigh=${Number(v.dayHigh).toFixed(3)}`);
  return parts.join(" | ").slice(0, 480);
}

async function pollPositions() {
  const cfg = await chrome.storage.local.get(["token", "enabled"]);
  if (cfg.enabled === false) return;
  if (!cfg.token) { lastPositionsError = "no_token_configured"; return; }
  try {
    const res = await fetch(POSITIONS_ENDPOINT, {
      method: "GET",
      headers: { "x-thunder-token": cfg.token },
    });
    lastPositionsPoll = Date.now();
    if (!res.ok) { lastPositionsError = `positions_http_${res.status}`; return; }
    const json = await res.json();
    const list = Array.isArray(json?.positions) ? json.positions : [];
    const next = {};
    for (const p of list) {
      const sym = normalizeSymbol(p.symbol);
      if (!sym) continue;
      next[sym] = {
        id: p.id,
        qty: Number(p.quantity) || 0,
        tp: Number(p.target_price) || 0,
        sl: Math.max(Number(p.stop_loss) || 0, Number(p.trailing_stop) || 0),
        entry: Number(p.entry_price) || 0,
        current: Number(p.current_price) || 0,
      };
    }
    openPositions = next;
      broadcastToThunderTabs({ type: "positionsUpdate", payload: openPositions });
    // Drop triggered entries for positions that are no longer open.
    for (const pid of Object.keys(triggeredSells)) {
      const stillOpen = Object.values(openPositions).some((p) => p.id === pid);
      if (!stillOpen) delete triggeredSells[pid];
    }
    lastPositionsError = null;
  } catch (e) {
    lastPositionsError = String(e?.message || e);
  }
}

async function checkLocalSell(symbol, price) {
  const sym = normalizeSymbol(symbol);
  const pos = openPositions[sym];
  if (!pos) return;
  if (triggeredSells[pos.id]) return;
  if (!(price > 0)) return;

  let reason = null;
  if (pos.tp > 0 && price >= pos.tp) reason = "target_hit";
  else if (pos.sl > 0 && price <= pos.sl) reason = "stop_hit";
  if (!reason) return;

  triggeredSells[pos.id] = Date.now();
  // v4.1.69: TP hit prepares the SELL form immediately, but still stops
  // before "مراجعة الطلب". This restores capital-rotation speed without
  // returning to fully automatic selling. Stop-loss stays alert-only because
  // it is not a profit exit.
  broadcastToThunderTabs({
    type: "positionAlert",
    payload: { symbol: sym, reason, price, position_id: pos.id },
  });
  if (reason !== "target_hit") {
    lastPositionsError = `sl_hit_${sym}_alert_only`;
    return;
  }
  lastPositionsError = `tp_sl_hit_${sym}_${reason}_preparing_sell`;
  prepareLocalSellFromPosition(sym, pos, price, reason).catch((e) => {
    lastPositionsError = `local_sell_prepare_failed_${sym}: ${String(e?.message || e)}`;
    // Allow one later retry if preparation failed before opening the form.
    delete triggeredSells[pos.id];
  });
}

async function prepareLocalSellFromPosition(symbol, pos, price, reason) {
  const sym = normalizeSymbol(symbol);
  if (!sym || !pos?.id) return;
  const uuid = uuidForSymbol(sym);
  if (!uuid) {
    broadcastToThunderTabs({
      type: "positionAlert",
      payload: { symbol: sym, reason, price, position_id: pos.id, error: "uuid_not_mapped" },
    });
    throw new Error(`uuid_not_mapped_${sym}`);
  }
  const targetUrl = `https://web.thndr.app/ar/assets/${uuid}`;
  const tab = await chrome.tabs.create({ url: targetUrl, active: true });
  try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch {}
  const orderId = `auto-sell-local-${pos.id}-${Date.now()}`;
  const refPrice = Number(pos.entry) || Number(price) || 0;
  const result = await sendExecuteOrderWhenReady(tab.id, {
    type: EXECUTE_ORDER_MESSAGE,
    payload: {
      orderId,
      symbol: sym,
      uuid,
      qty: Number(pos.qty) || 0,
      egp: 0,
      side: "sell",
      orderType: "limit",
      limitPrice: Number(pos.tp) || 0,
      refPrice,
      driftBps: 100,
      signalSource: `local_${reason}`,
      signalCreatedAt: new Date().toISOString(),
      metadata: { position_id: pos.id, reason, trigger_price: Number(price) || null, target_price: Number(pos.tp) || null, stop_loss: Number(pos.sl) || null },
    },
  }, 90_000);
  if (!result?.ok) throw new Error(result?.stage || result?.error || "sell_prepare_not_ok");
  lastPositionsError = `sell_prepared_${sym}_${reason}`;
}

async function flush() {
  if (buffer.length === 0) return;
  const { enabled, endpoint, token } = await chrome.storage.local.get(["enabled", "endpoint", "token"]);
  if (enabled === false) return;
  if (!token) { stats.lastError = "no_token_configured"; return; }
  const url = endpoint || DEFAULT_ENDPOINT;

  const batch = buffer.splice(0, buffer.length);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-thunder-token": token },
      body: JSON.stringify({ ticks: batch }),
    });
    if (!res.ok) {
      stats.lastError = `http_${res.status}`;
      buffer = batch.concat(buffer).slice(-MAX_BUFFER);
      return;
    }
    const json = await res.json().catch(() => ({}));
    stats.sent += (json?.inserted ?? batch.length);
    stats.lastFlush = Date.now();
    stats.lastError = null;
  } catch (e) {
    stats.lastError = String(e?.message || e);
    buffer = batch.concat(buffer).slice(-MAX_BUFFER);
  } finally {
    chrome.storage.local.set({ stats });
  }
}

// -------------------- Orders polling (Semi-Auto) --------------------

async function pollOrders() {
  const cfg = await chrome.storage.local.get(["token", "autoExec", "maxPerDay", "egpPerTrade", "enabled", "qtyMode", "fixedQty", "alwaysNewTab"]);
  if (cfg.enabled === false) return;
  if (cfg.autoExec !== true) return;
  // Phase 3: kill switch + global toggle من Remote Config (لحظي)
  if (getConfig("kill_switch", false) === true) { lastOrderError = "kill_switch_active"; return; }
  if (getConfig("semi_auto_enabled", true) === false) { lastOrderError = "semi_auto_disabled_globally"; return; }
  if (!cfg.token) { lastOrderError = "no_token_configured"; return; }

  const max = cfg.maxPerDay ?? 3;
  if (Object.keys(dispatchedToday).length + Object.keys(inFlightOrders).length >= max) {
    lastOrderError = `daily_cap_reached_${max}`;
    return;
  }

  try {
    const res = await fetch(ORDERS_ENDPOINT, {
      method: "GET",
      headers: { "x-thunder-token": cfg.token },
    });
    lastOrderPoll = Date.now();
    if (!res.ok) { lastOrderError = `orders_http_${res.status}`; return; }
    const json = await res.json();
    const orders = Array.isArray(json?.orders) ? json.orders : [];
    lastOrderError = null;

    for (const o of orders) {
      if (dispatchedToday[o.id] || inFlightOrders[o.id] || failedOrders[o.id]) continue;
      if (!["pending", "opened"].includes(o.status)) continue;
      if (o.expires_at && new Date(o.expires_at).getTime() <= Date.now()) continue;

      // Prefer uuid resolved from Thunder live ticks (v3 debugger extension),
      // fallback to old local watchlist mapping if available.
      const uuid = normalizeUuid(o.uuid) || uuidForSymbol(o.symbol);
      if (!uuid) {
        lastOrderError = `uuid_not_mapped_${o.symbol} — شغّل v3 على ثندر أو افتح قائمة المراقبة`;
        continue;
      }

      // Quantity decision (extension-side only — لا يمس الاستراتيجية):
      //  1) server-provided qty يفوز دائماً.
      //  2) qtyMode=fixed + fixedQty>0 → استخدم العدد الثابت.
      //  3) auto (افتراضي): المبلغ ÷ السعر اللحظي.
      const egp = Math.max(MIN_SCALP_CASH_EGP, Number(cfg.egpPerTrade) || MIN_SCALP_CASH_EGP);
      const price = Number(o.ref_price) || 0;
      const explicitQty = Number(o.qty);
      const fixedQty = Math.floor(Number(cfg.fixedQty) || 0);
      let qty;
      if (Number.isFinite(explicitQty) && explicitQty > 0) {
        qty = Math.floor(explicitQty);
      } else if (cfg.qtyMode === "fixed" && fixedQty > 0) {
        qty = fixedQty;
      } else {
        qty = price > 0 ? Math.max(1, Math.floor(egp / price)) : 1;
      }

      // v4.1.62 — Trade Viability Guard (BUY only): rejects mathematically bad
      // entries before opening Thunder.  This closes the WKOL-type hole where
      // a tiny notional or a slipped entry needs an unreachable sell price after
      // fees.  SELL orders are never blocked by this guard.
      const viability = assessBuyViability(o, { qty, egp, qtyMode: cfg.qtyMode === "fixed" ? "fixed" : "auto" });
      if (!viability.ok) {
        const msg = "viability_blocked: " + formatViabilityBlock(viability);
        lastOrderError = msg;
        failedOrders[o.id] = true;
        reportOrderStatus({ id: o.id, status: "error", error_message: msg });
        continue;
      }

      if (Object.keys(dispatchedToday).length + Object.keys(inFlightOrders).length >= max) break;
      inFlightOrders[o.id] = true;

      // Timeline: signal received by extension (before we touch Thunder).
      recordTimelineEvent({
        signal_id: String(o.id),
        symbol: normalizeSymbol(o.symbol),
        uuid,
        event: "signal_received",
        at_ms: Date.now(),
        meta: {
          side: o.side,
          ref_price: Number(o.ref_price) || null,
          order_type: o.order_type || null,
          limit_price: Number(o.limit_price) || null,
          qty,
          signal_created_at: o.created_at || null,
          signal_source: o.signal_source || null,
        },
      }).catch(() => {});

      // v4.1.60: نفتح تاب جديدة في نفس النافذة الحالية (مش نافذة منفصلة).
      // ده بيخلي تاب قائمة المراقبة محتفظة باتصال CDP بدون قطع، ومفيش
      // إشعار "انقطع الاتصال بثاندر" بعد كل إشارة. الـ throttling مش
      // بيقطع long-polling لأن التاب لسه موجودة في نفس النافذة المرئية،
      // والـ silent audio + autoDiscardable=false كفيلين بإبقائها نشطة.
      const targetUrl = `https://web.thndr.app/ar/assets/${uuid}`;
      let tab;
      try {
        tab = await chrome.tabs.create({ url: targetUrl, active: true });
        try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch {}
        recordTimelineEvent({
          signal_id: String(o.id),
          symbol: normalizeSymbol(o.symbol),
          uuid,
          event: "tab_opened",
          at_ms: Date.now(),
          meta: { tab_id: tab?.id || null },
        }).catch(() => {});
      } catch (e2) {
        lastOrderError = "tab_open_failed: " + String(e2?.message || e2);
        failedOrders[o.id] = true;
        delete inFlightOrders[o.id];
        continue;
      }

      prepareOrderInTab(tab.id, {
        type: EXECUTE_ORDER_MESSAGE,
        payload: {
          orderId: o.id,
          symbol: o.symbol,
          uuid,
          qty,
          egp,
          side: o.side,
          orderType: o.order_type,
          limitPrice: Number(o.limit_price) || 0,
          refPrice: Number(o.ref_price) || 0,
          driftBps: 100, // 1% adverse move triggers warning
          signalSource: o.signal_source,
          signalCreatedAt: o.created_at,
          metadata: o.metadata || null,
        },
      }).catch((e) => {
        lastOrderError = "prepare_failed: " + String(e?.message || e);
        failedOrders[o.id] = true;
        reportOrderStatus({ id: o.id, status: "error", error_message: lastOrderError });
      }).finally(() => {
        delete inFlightOrders[o.id];
      });
    }
  } catch (e) {
    lastOrderError = String(e?.message || e);
  }
}

function uuidForSymbol(symbol) {
  const want = normalizeSymbol(symbol);
  for (const [uuid, m] of Object.entries(mapping)) {
    if (normalizeSymbol(m?.symbol) === want) return uuid;
  }
  return null;
}

function normalizeSymbol(symbol) {
  return String(symbol || "").trim().toUpperCase();
}

function normalizeUuid(value) {
  const s = String(value || "").trim().toLowerCase();
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(s) ? s : null;
}

async function autoInjectThunderTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: ["https://web.thndr.app/*", "https://*.thndr.app/*"] });
    let injected = 0;
    for (const tab of tabs) {
      if (!tab?.id || !isSafeThndrUrl(tab.url)) continue;
      try {
        await ensureContentScript(tab.id);
        // Prevent Chrome from auto-discarding the watchlist / price tab when
        // it sits in the background for a long time. Discarded tabs lose
        // their long-polling connection silently.
        try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch {}
        injected++;
      } catch (e) {
        stats.injectError = String(e?.message || e);
      }
    }
    stats.injectedTabs = injected;
    stats.lastInject = Date.now();
    if (injected > 0) stats.injectError = null;
    chrome.storage.local.set({ stats }).catch(() => {});
  } catch (e) {
    stats.injectError = String(e?.message || e);
    chrome.storage.local.set({ stats }).catch(() => {});
  }
}

async function pollBackendLiveTicks() {
  const { enabled } = await chrome.storage.local.get(["enabled"]);
  if (enabled === false) return;
  try {
    const res = await fetch(BACKEND_LIVE_POLL_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}",
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      stats.lastError = `backend_poll_http_${res.status}`;
      return;
    }
    stats.backendPolls = (stats.backendPolls || 0) + 1;
    stats.backendPollRows = (stats.backendPollRows || 0) + (Number(json?.fetched) || 0);
    stats.sent = (stats.sent || 0) + (Number(json?.fetched) || 0);
    if (json?.sample?.symbol && Number(json.sample.price) > 0) {
      stats.lastTick = { symbol: normalizeSymbol(json.sample.symbol), price: Number(json.sample.price), ts: Date.now() };
    }
    stats.lastBackendPoll = Date.now();
    stats.lastFlush = Date.now();
    stats.lastError = json?.skipped ? `backend_poll_${json.skipped}` : null;
  } catch (e) {
    stats.lastError = "backend_poll_failed: " + String(e?.message || e);
  } finally {
    chrome.storage.local.set({ stats }).catch(() => {});
  }
}

async function broadcastToThunderTabs(message) {
  try {
    const tabs = await chrome.tabs.query({ url: ["https://web.thndr.app/*", "https://*.thndr.app/*"] });
    for (const t of tabs) {
      if (!t?.id) continue;
      chrome.tabs.sendMessage(t.id, message).catch(() => {});
    }
  } catch {}
}

async function prepareOrderInTab(tabId, message) {
  const result = await sendExecuteOrderWhenReady(tabId, message, 90_000);
  // v4.1.71: L2 guard rejected the signal → don't leave the tab open confusing the user.
  // Close the tab, mark the order rejected on the server, and fire a clear notification.
  if (result && result.ok === false && result.stage === "l2_guard_rejected") {
    const reason = String(result.reason || "L2 غير آمن");
    try {
      chrome.notifications?.create?.({
        type: "basic",
        iconUrl: chrome.runtime.getURL("icon.png"),
        title: `🛑 ${message?.payload?.symbol || "الإشارة"} — اترفضت`,
        message: `الاكستنشن رفض الشراء وقفل التاب.\nالسبب: ${reason}\nمش محتاج تعمل حاجة.`,
        priority: 2,
      });
    } catch {}
    try {
      await reportOrderStatus({
        id: message?.payload?.orderId,
        status: "error",
        error_message: `l2_guard_rejected: ${reason}`,
      });
    } catch {}
    // Close the confusing tab after a short delay so the user can see the L2 debug overlay.
    setTimeout(() => { try { chrome.tabs.remove(tabId); } catch {} }, 1500);
    lastOrderError = `l2_guard_rejected: ${reason}`;
    return result;
  }
  if (!result?.ok) throw new Error(result?.error || result?.stage || "prepare_not_ok");
  dispatchedToday[message.payload.orderId] = true;
  lastOrderError = null;
  return result;
}

function isSafeThndrUrl(url) {
  return /^https:\/\/([^/]+\.)?thndr\.app\//.test(String(url || ""));
}

async function waitForTabReady(tabId, timeoutMs = 25_000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab?.status === "complete" && /^https:\/\/([^/]+\.)?thndr\.app\//.test(tab.url || "")) return true;
    } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }
  return false;
}

async function runLocalOrderTest() {
  const cfg = await chrome.storage.local.get(["egpPerTrade"]);
  const egp = Math.max(MIN_SCALP_CASH_EGP, Number(cfg.egpPerTrade) || MIN_SCALP_CASH_EGP);
  const entry = Object.entries(mapping).find(([uuid, m]) => uuid && m?.symbol);
  const [uuid, m] = entry || [null, { symbol: "TEST" }];
  const symbol = normalizeSymbol(m.symbol);
  const tabs = await chrome.tabs.query({ url: ["https://web.thndr.app/*", "https://*.thndr.app/*"] });
  const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
  let tab = activeTabs.find((t) => /^https:\/\/([^/]+\.)?thndr\.app\//.test(t.url || "")) || tabs[0];
  if (!tab && uuid) {
    tab = await chrome.tabs.create({ url: `https://web.thndr.app/ar/assets/${uuid}`, active: true });
  } else if (!tab) {
    tab = await chrome.tabs.create({ url: "https://web.thndr.app/ar", active: true });
  } else if (uuid) {
    await chrome.tabs.update(tab.id, { active: true, url: `https://web.thndr.app/ar/assets/${uuid}` });
  } else {
    await chrome.tabs.update(tab.id, { active: true });
  }
  const result = await sendExecuteOrderWhenReady(tab.id, {
      type: EXECUTE_ORDER_MESSAGE,
      payload: { orderId: `local-test-${Date.now()}`, symbol, uuid, qty: 1, egp, side: "buy" },
    }, uuid ? 90_000 : 20_000);
  lastOrderError = null;
  return { ok: !!result?.ok, symbol, version: result?.version };
}

// Phase 2-a test: open the SELL sidebar on an asset, choose "أسهم" tab,
// click "الحد الأقصى". Stops before review. The user picks any owned symbol
// from their watchlist (test uses the first mapped symbol). Same safety
// guarantees as runLocalOrderTest — local-test-* IDs are never reported to
// the server.
async function runLocalSellTest() {
  const entry = Object.entries(mapping).find(([uuid, m]) => uuid && m?.symbol);
  const [uuid, m] = entry || [null, { symbol: "TEST" }];
  const symbol = normalizeSymbol(m.symbol);
  const tabs = await chrome.tabs.query({ url: ["https://web.thndr.app/*", "https://*.thndr.app/*"] });
  const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
  let tab = activeTabs.find((t) => /^https:\/\/([^/]+\.)?thndr\.app\//.test(t.url || "")) || tabs[0];
  if (!tab && uuid) {
    tab = await chrome.tabs.create({ url: `https://web.thndr.app/ar/assets/${uuid}`, active: true });
  } else if (!tab) {
    tab = await chrome.tabs.create({ url: "https://web.thndr.app/ar", active: true });
  } else if (uuid) {
    await chrome.tabs.update(tab.id, { active: true, url: `https://web.thndr.app/ar/assets/${uuid}` });
  } else {
    await chrome.tabs.update(tab.id, { active: true });
  }
  const result = await sendExecuteOrderWhenReady(tab.id, {
      type: EXECUTE_ORDER_MESSAGE,
      payload: { orderId: `local-test-${Date.now()}`, symbol, uuid, qty: 0, egp: 0, side: "sell" },
    }, uuid ? 90_000 : 20_000);
  lastOrderError = null;
  return { ok: !!result?.ok, symbol, stage: result?.stage, version: result?.version };
}

// Dry-run: just opens a fresh Thunder tab for any mapped symbol (or a fallback
// URL) WITHOUT touching the form. Use this to verify that real signals will
// actually open a new tab in Thunder. No order is prepared or reported.
async function runOpenTabTest() {
  const entry = Object.entries(mapping).find(([uuid, m]) => uuid && m?.symbol);
  const [uuid, m] = entry || [null, null];
  const symbol = m?.symbol ? normalizeSymbol(m.symbol) : null;
  const url = uuid ? `https://web.thndr.app/ar/assets/${uuid}` : "https://web.thndr.app/ar";
  try {
    const tab = await chrome.tabs.create({ url, active: true });
    if (tab?.windowId != null) {
      try { await chrome.windows.update(tab.windowId, { focused: true }); } catch {}
    }
    return { ok: true, symbol: symbol || "(no mapped symbol)", tabId: tab?.id, url };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}

async function ensureContentScript(tabId) {
  try {
    const pong = await chrome.tabs.sendMessage(tabId, { type: "ping" });
    if (pong?.ok && pong.version === CONTENT_SCRIPT_VERSION) return true;
  } catch {}
  try {
    await chrome.scripting.executeScript({ target: { tabId, allFrames: false }, files: ["page-script.js"], world: "MAIN" });
  } catch {}
  try {
    await chrome.scripting.executeScript({ target: { tabId, allFrames: false }, files: ["content.js"], world: "ISOLATED" });
    await new Promise((r) => setTimeout(r, 200));
    return true;
  } catch (e) {
    throw new Error("content_script_inject_failed: " + String(e?.message || e));
  }
}

async function sendExecuteOrder(tabId, message) {
  await ensureContentScript(tabId);
  return chrome.tabs.sendMessage(tabId, message);
}

async function sendExecuteOrderWhenReady(tabId, message, timeoutMs = 12_000) {
  const start = Date.now();
  let lastErr = null;
  let lastResult = null;
  while (Date.now() - start < timeoutMs) {
    try {
      const res = await sendExecuteOrder(tabId, message);
      lastResult = res;
      if (res?.ok) return res;
      if (["l2_guard_rejected", "order_type_not_selected", "order_type_advanced_not_selected", "settlement_t0_not_selected", "limit_price_not_filled", "qty_input_not_found", "qty_type_failed", "side_button_not_found", "side_button_no_form", "cash_mode_not_verified", "cash_amount_missing", "shares_mode_not_verified", "max_button_not_found", "max_qty_not_filled"].includes(res?.stage)) {
        return res;
      }
      if (res?.retryAfterNavigation) {
        if (res.thndrXUrl && isSafeThndrUrl(res.thndrXUrl)) {
          await chrome.tabs.update(tabId, { active: true, url: res.thndrXUrl });
        }
        tabId = await waitForLikelyTradingTab(tabId, 35_000);
        await waitForTabReady(tabId, 35_000);
        await new Promise((r) => setTimeout(r, 1800));
        continue;
      }
    } catch (e) {
      lastErr = e;
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error(lastErr?.message || lastResult?.stage || "thunder_page_not_ready");
}

async function waitForLikelyTradingTab(preferredTabId, timeoutMs = 35_000) {
  const start = Date.now();
  let best = preferredTabId;
  while (Date.now() - start < timeoutMs) {
    try {
      const preferred = await chrome.tabs.get(preferredTabId);
      if (isSafeThndrUrl(preferred?.url)) {
        best = preferred.id;
        if (isLikelyTradingUrl(preferred.url)) return preferred.id;
      }
    } catch {}
    try {
      const tabs = await chrome.tabs.query({ url: ["https://web.thndr.app/*", "https://*.thndr.app/*"] });
      const trading = tabs.find((t) => isLikelyTradingUrl(t.url));
      if (trading?.id) return trading.id;
      const active = tabs.find((t) => t.active && t.id);
      if (active?.id) best = active.id;
    } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }
  return best;
}

function isLikelyTradingUrl(url) {
  const u = String(url || "").toLowerCase();
  return isSafeThndrUrl(u) && (/thndrx|trader|trade|terminal|workspace|market/.test(u) || !/\/assets\//.test(u));
}

async function reportOrderStatus({ id, status, error_message }) {
  const sid = String(id || "");
  if (sid.startsWith("local-test-") || sid.startsWith("auto-sell-") || sid.startsWith("auto-sell-local-") || sid.startsWith("manual-auto-sell-")) return;
  const { token } = await chrome.storage.local.get(["token"]);
  if (!token) return;
  try {
    await fetch(ORDERS_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-thunder-token": token },
      body: JSON.stringify({ id, status, error_message }),
    });
  } catch {}
}

async function recordOrderbookSnapshot(snap) {
  const uuid = normalizeUuid(snap?.uuid);
  if (!uuid) return;
  const symbol = normalizeSymbol(snap?.symbol || mapping[uuid]?.symbol);
  if (!symbol) return;
  const { token } = await chrome.storage.local.get(["token"]);
  if (!token) return;
  try {
    await fetch(ORDERBOOK_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-thunder-token": token },
      body: JSON.stringify({
        symbol,
        ts: snap.ts || Date.now(),
        best_bid: Number(snap.bestBid) || null,
        best_bid_qty: Number(snap.bestBidQty) || null,
        best_ask: Number(snap.bestAsk) || null,
        best_ask_qty: Number(snap.bestAskQty) || null,
        last_price: Number(latestPriceBySymbol[symbol]?.price) || null,
        bids: Array.isArray(snap.bids) ? snap.bids : [],
        asks: Array.isArray(snap.asks) ? snap.asks : [],
        source: "thunder_l2_ext",
      }),
    });
  } catch {}
}

// Timeline telemetry — fire-and-forget. Any failure is swallowed so it can
// NEVER block a buy/sell decision. Batches or single events accepted.
async function recordTimelineEvent(payload) {
  try {
    const events = Array.isArray(payload) ? payload : [payload];
    const clean = [];
    for (const e of events) {
      if (!e || typeof e !== "object") continue;
      const symbol = normalizeSymbol(e.symbol);
      const event = String(e.event || "").trim();
      const at_ms = Number(e.at_ms);
      if (!symbol || !event || !Number.isFinite(at_ms) || at_ms <= 0) continue;
      clean.push({
        signal_id: e.signal_id ? String(e.signal_id) : null,
        symbol,
        uuid: e.uuid ? String(e.uuid).toLowerCase() : null,
        event,
        at_ms,
        meta: (e.meta && typeof e.meta === "object") ? e.meta : {},
      });
    }
    if (!clean.length) return;
    const { token } = await chrome.storage.local.get(["token"]);
    if (!token) return;
    await fetch(TIMELINE_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-thunder-token": token },
      body: JSON.stringify({ events: clean }),
    });
  } catch {}
}

// Passive watchlist snapshotting — throttled per uuid to 1/hour.
const watchlistLastSent = {};
async function recordWatchlistSnapshots(arr) {
  if (!Array.isArray(arr) || !arr.length) return;
  const { token } = await chrome.storage.local.get(["token"]);
  if (!token) return;
  const now = Date.now();
  const HOUR = 60 * 60_000;
  const items = [];
  for (const it of arr) {
    if (!it?.symbol || !it?.uuid) continue;
    const key = String(it.uuid).toLowerCase();
    const last = watchlistLastSent[key] || 0;
    if (now - last < HOUR) continue;
    watchlistLastSent[key] = now;
    items.push({
      symbol: String(it.symbol).toUpperCase(),
      uuid: key,
      name: it.name ?? null,
      day_tradable: typeof it.day_tradable === "boolean" ? it.day_tradable : null,
      feed_price: Number(it.feed_price) || null,
      previous_close: Number(it.previous_close) || null,
      min_price_limit: Number(it.min_price_limit) || null,
      max_price_limit: Number(it.max_price_limit) || null,
      day_trade_limit: Number(it.day_trade_limit) || null,
      round_digits: Number.isFinite(it.round_digits) ? it.round_digits : null,
      market_id: it.market_id ?? null,
    });
  }
  if (!items.length) return;
  // GC cache to prevent unbounded growth.
  for (const [k, ts] of Object.entries(watchlistLastSent)) {
    if (now - Number(ts) > 24 * HOUR) delete watchlistLastSent[k];
  }
  try {
    await fetch(WATCHLIST_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-thunder-token": token },
      body: JSON.stringify({ items }),
    });
  } catch {}
}

// Bridge: send confirmed Thunder buy fills to the server so a `positions` row
// (with TP/SL from paper_trades) gets created and the sell-watcher can act.
// Local 10-minute dedupe by (symbol, qty, price) avoids hammering the server
// when Thunder repeats the same order in successive responses.
async function registerBuyFills(fills) {
  if (!Array.isArray(fills) || !fills.length) return;
  const { token } = await chrome.storage.local.get(["token"]);
  if (!token) return;
  const now = Date.now();
  // Garbage-collect dedupe cache so it can't grow forever.
  for (const [k, ts] of Object.entries(registeredBuyFills)) {
    if (now - Number(ts) > 60 * 60_000) delete registeredBuyFills[k];
  }
  for (const raw of fills) {
    const symbol = String(raw?.symbol || "").trim().toUpperCase();
    const qty = Number(raw?.qty);
    const entryPrice = Number(raw?.entry_price);
    if (!symbol || !(qty > 0) || !(entryPrice > 0)) continue;
    const key = `${symbol}|${Math.floor(qty)}|${entryPrice.toFixed(4)}`;
    if (registeredBuyFills[key] && now - registeredBuyFills[key] < 10 * 60_000) continue;
    registeredBuyFills[key] = now;
    try {
      const res = await fetch(POSITIONS_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-thunder-token": token },
        body: JSON.stringify({
          action: "register_buy_fill",
          symbol, qty, entry_price: entryPrice,
          source: String(raw?.source || "thunder_fill").slice(0, 64),
        }),
      });
      const json = await res.json().catch(() => ({}));
      await upsertLocalTradeFromFill({ symbol, qty, entryPrice, server: json });
      await journalRecordBuy({ symbol, qty, price: entryPrice, source: raw?.source }).catch(() => {});
    } catch {}
  }
}

async function registerSellFills(fills) {
  if (!Array.isArray(fills) || !fills.length) return;
  for (const raw of fills) {
    const symbol = normalizeSymbol(raw?.symbol);
    const qty = Number(raw?.qty) || 0;
    const exitPrice = Number(raw?.exit_price || raw?.price) || 0;
    if (!symbol) continue;
    await markLocalTradeSold({ symbol, qty, exitPrice });
    await journalRecordSell({ symbol, qty, exitPrice }).catch(() => {});
  }
}

async function getTradeStores() {
  const s = await chrome.storage.local.get([ACTIVE_TRADE_LEDGER_KEY, SIGNAL_LEDGER_KEY]);
  return {
    trades: (s[ACTIVE_TRADE_LEDGER_KEY] && typeof s[ACTIVE_TRADE_LEDGER_KEY] === "object") ? s[ACTIVE_TRADE_LEDGER_KEY] : {},
    signals: (s[SIGNAL_LEDGER_KEY] && typeof s[SIGNAL_LEDGER_KEY] === "object") ? s[SIGNAL_LEDGER_KEY] : {},
  };
}

async function upsertLocalTradeFromFill({ symbol, qty, entryPrice, server }) {
  const sym = normalizeSymbol(symbol);
  if (!sym || !(entryPrice > 0)) return;
  const { trades, signals } = await getTradeStores();
  const sig = signals[sym] || {};
  const prev = trades[sym] || {};
  const now = Date.now();
  trades[sym] = {
    ...prev,
    status: "open",
    symbol: sym,
    uuid: prev.uuid || sig.uuid || "",
    signalId: sig.signalId || prev.signalId || String(server?.paper_trade_id || ""),
    signalSource: sig.signalSource || prev.signalSource || "scalp-live",
    source: "thunder_fill",
    qty: Math.max(1, Math.floor(qty)),
    entryPrice: Number(entryPrice),
    boughtAt: Number(prev.boughtAt) || now,
    updatedAt: now,
    serverPositionId: server?.position_id || prev.serverPositionId || null,
  };
  await chrome.storage.local.set({ [ACTIVE_TRADE_LEDGER_KEY]: trades });
}

async function markLocalTradeSold({ symbol, qty, exitPrice }) {
  const sym = normalizeSymbol(symbol);
  if (!sym) return;
  const { trades } = await getTradeStores();
  const prev = trades[sym] || { symbol: sym };
  trades[sym] = {
    ...prev,
    status: "closed",
    soldAt: Date.now(),
    updatedAt: Date.now(),
    exitQty: Number(qty) || Number(prev.qty) || 0,
    exitPrice: Number(exitPrice) || Number(prev.exitPrice) || 0,
  };
  await chrome.storage.local.set({ [ACTIVE_TRADE_LEDGER_KEY]: trades });
}

// =================== Trade Journal (P&L per trade + per day) ===================

async function readJournal() {
  const s = await chrome.storage.local.get([TRADE_JOURNAL_KEY]);
  const j = s[TRADE_JOURNAL_KEY];
  return (j && typeof j === "object") ? j : {};
}
async function writeJournal(j) {
  await chrome.storage.local.set({ [TRADE_JOURNAL_KEY]: j });
}
function summariseDay(rows) {
  let realised = 0, openCount = 0, closedCount = 0, wins = 0, losses = 0;
  let totalBuy = 0, totalSell = 0, totalFees = 0;
  for (const r of rows || []) {
    totalBuy += Number(r.buy_value) || 0;
    totalFees += (Number(r.buy_fee) || 0) + (Number(r.sell_fee) || 0);
    if (r.status === "closed") {
      closedCount++;
      realised += Number(r.pnl) || 0;
      totalSell += Number(r.sell_value) || 0;
      if ((Number(r.pnl) || 0) >= 0) wins++; else losses++;
    } else openCount++;
  }
  return {
    realised: +realised.toFixed(2),
    totalBuy: +totalBuy.toFixed(2),
    totalSell: +totalSell.toFixed(2),
    totalFees: +totalFees.toFixed(2),
    openCount, closedCount, wins, losses,
    count: (rows || []).length,
  };
}
async function getTradeJournal(dateArg) {
  const date = dateArg || cairoDateStr();
  const j = await readJournal();
  const rows = (j[date] || []).slice().sort((a, b) => (b.opened_at || 0) - (a.opened_at || 0));
  return { ok: true, date, rows, summary: summariseDay(rows) };
}

async function syncTradeToServer(row) {
  try {
    const { token } = await chrome.storage.local.get(["token"]);
    if (!token) return;
    await fetch(TRADES_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-thunder-token": token },
      body: JSON.stringify({
        client_trade_id: row.client_trade_id,
        symbol: row.symbol,
        trade_date: row.trade_date,
        source: row.source || "thunder_fill",
        status: row.status,
        opened_at: new Date(row.opened_at).toISOString(),
        buy_qty: row.buy_qty ?? null,
        buy_price: row.buy_price ?? null,
        buy_value: row.buy_value ?? null,
        buy_fee: row.buy_fee ?? null,
        buy_total_cost: row.buy_total_cost ?? null,
        closed_at: row.closed_at ? new Date(row.closed_at).toISOString() : null,
        sell_qty: row.sell_qty ?? null,
        sell_price: row.sell_price ?? null,
        sell_value: row.sell_value ?? null,
        sell_fee: row.sell_fee ?? null,
        sell_net_proceeds: row.sell_net_proceeds ?? null,
        pnl: row.pnl ?? null,
        pnl_pct: row.pnl_pct ?? null,
      }),
    });
  } catch {}
}

async function journalRecordBuy({ symbol, qty, price, source }) {
  const sym = normalizeSymbol(symbol);
  const q = Math.max(0, Number(qty) || 0);
  const p = Number(price) || 0;
  if (!sym || !(q > 0) || !(p > 0)) return;
  const date = cairoDateStr();
  const j = await readJournal();
  const rows = j[date] || [];
  // dedupe: an open row for the same symbol with the same qty+price = same fill
  const dupKey = `${sym}|${Math.floor(q)}|${p.toFixed(4)}`;
  if (rows.some(r => r.status === "open" && `${r.symbol}|${Math.floor(r.buy_qty || 0)}|${(Number(r.buy_price) || 0).toFixed(4)}` === dupKey)) return;
  const buyValue = +(q * p).toFixed(4);
  const buyFee = calcFee(buyValue);
  const now = Date.now();
  const row = {
    client_trade_id: `ext-${sym}-${now}`,
    symbol: sym,
    trade_date: date,
    source: source || "thunder_fill",
    status: "open",
    opened_at: now,
    buy_qty: q,
    buy_price: p,
    buy_value: buyValue,
    buy_fee: buyFee,
    buy_total_cost: +(buyValue + buyFee).toFixed(4),
  };
  rows.push(row);
  j[date] = rows;
  await writeJournal(j);
  syncTradeToServer(row).catch(() => {});
}

async function journalRecordSell({ symbol, qty, exitPrice }) {
  const sym = normalizeSymbol(symbol);
  const p = Number(exitPrice) || 0;
  if (!sym || !(p > 0)) return;
  const date = cairoDateStr();
  const j = await readJournal();
  // Match the OLDEST open row for this symbol (FIFO)
  for (const dKey of [date, ...Object.keys(j).filter(k => k !== date)]) {
    const rows = j[dKey] || [];
    const idx = rows.findIndex(r => r.symbol === sym && r.status === "open");
    if (idx < 0) continue;
    const row = rows[idx];
    const q = Number(qty) || Number(row.buy_qty) || 0;
    if (!(q > 0)) return;
    const sellValue = +(q * p).toFixed(4);
    const sellFee = calcFee(sellValue);
    const sellNet = +(sellValue - sellFee).toFixed(4);
    const buyTotal = Number(row.buy_total_cost) || 0;
    const pnl = +(sellNet - buyTotal).toFixed(4);
    const pnlPct = buyTotal > 0 ? +((pnl / buyTotal) * 100).toFixed(3) : null;
    rows[idx] = {
      ...row,
      status: "closed",
      closed_at: Date.now(),
      sell_qty: q,
      sell_price: p,
      sell_value: sellValue,
      sell_fee: sellFee,
      sell_net_proceeds: sellNet,
      pnl,
      pnl_pct: pnlPct,
    };
    j[dKey] = rows;
    await writeJournal(j);
    syncTradeToServer(rows[idx]).catch(() => {});
    return;
  }
}

// Reset dispatchedToday at Cairo midnight (cheap: clear at 5am UTC)
function maybeResetDay() {
  const d = new Date();
  if (d.getUTCHours() === 5 && d.getUTCMinutes() < 5) { dispatchedToday = {}; failedOrders = {}; }
}

setInterval(flush, FLUSH_MS);
setInterval(autoInjectThunderTabs, AUTO_INJECT_MS);
setInterval(pollOrders, ORDER_POLL_MS);
setInterval(pollPositions, POSITIONS_POLL_MS);
setInterval(maybeResetDay, 60_000);
autoInjectThunderTabs().catch(() => {});
